# Lean supplement: Measurable Deviations

Release prepared 25 October 2026.

## Contents

- `formal/`: 16 mathematical modules, the root `Envelope.lean`, `AxiomAudit.lean`, and the pinned Lake configuration and dependency manifest.
- `outputs/claim-map.md`: historical manuscript-to-declaration map, dated 4 October 2026.
- `outputs/theorem-index.json`: public theorem names and source locations.
- `outputs/verification.json`: unmodified historical verification record.
- `source-manifest.json`: SHA-256 hashes and historical comparison for every other file in this archive.

The manuscript PDF, dependency caches, compiled objects, build logs, and credentials are not included.

## Build

Install Lean's `elan` toolchain manager and Git. From the extracted archive:

```sh
cd formal
lake exe cache get
lake build
```

The checked-in `lean-toolchain` selects Lean 4.30.0. The dependency manifest pins mathlib to `c5ea00351c28e24afc9f0f84379aa41082b1188f`. Keep that manifest unchanged to reproduce the recorded dependency versions. The cache command downloads dependency build artifacts; the build then checks both default targets, `Envelope` and `AxiomAudit`. The latter uses `#print axioms` to report declaration dependencies. The historical permitted foundations are `propext`, `Classical.choice`, and `Quot.sound`.

## Verification status and scope

This release was assembled without rerunning Lean. All 21 formal project files and both mapping/index artifacts match their SHA-256 hashes in the historical record exactly: 23 of 23 comparisons passed. The historical record is dated `2026-10-04T20:21:21.540817+00:00` and reports a successful build and axiom audit covering 241 public theorem declarations and two additional named instances. It also distinguishes later editorial checks from the earlier Lean build.

The manuscript hash, compilation report, revision descriptions, and dates inside the historical record concern the October 4 manuscript; they are not a certification of the subsequently revised PDF. The claim map is included unchanged as a historical map. The formal source has not changed. SHA-256 matching establishes file identity with that recorded evidence; it is not a fresh build. `source-manifest.json` records the current release hashes, including the historical record's own hash. The manifest excludes itself to avoid a circular hash.

The project formalizes the revised numbered mathematical results and additional counterexamples described in the claim map. Interpretation of the cited paper, proof-dependency diagrams, economic importance, and publication claims are outside the formal scope. Lean's integral is totalized; the counterexamples separately prove nonmeasurability/nonintegrability, and the repaired statements separately establish integrability, as explained in the claim map.
