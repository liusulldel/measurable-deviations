import Mathlib.MeasureTheory.Function.StronglyMeasurable.Basic
import Mathlib.MeasureTheory.Integral.IntegrableOn
import Mathlib.Topology.ContinuousMap.Compact
import Mathlib.Topology.MetricSpace.Polish

/-! Measurability belongs to the selected payoff path, not to arbitrary action labels.
The results below use a compact family of continuous payoff profiles, and also give
an alternative Caratheodory criterion on an arbitrary measurable action space. -/

open Set MeasureTheory Topology
open scoped ENNReal

namespace Envelope

section CountableTests

variable {T S : Type*} [MetricSpace T] [MeasurableSpace S]

local instance : MeasurableSpace C(T, ℝ) := borel _
local instance : BorelSpace C(T, ℝ) := ⟨rfl⟩

/-- Evaluations on a dense sequence distinguish continuous payoff profiles. -/
theorem dense_evaluations_injective (d : ℕ → T) (hd : DenseRange d)
    (K : Set C(T, ℝ)) :
    Function.Injective (fun g : K => fun n : ℕ => g.val (d n)) := by
  intro g h heq
  apply Subtype.ext
  apply DFunLike.ext'
  exact hd.equalizer g.val.continuous h.val.continuous heq

/-- For a compact family, countably many scalar tests exactly characterize
measurability of a profile-valued selection. No structure on action labels occurs. -/
theorem measurable_profile_iff_dense_evaluations (d : ℕ → T) (hd : DenseRange d)
    (K : Set C(T, ℝ)) (hK : IsCompact K) (g : S → K) :
    Measurable g ↔ ∀ n : ℕ, Measurable (fun s => (g s).val (d n)) := by
  letI : CompactSpace K := isCompact_iff_compactSpace.mp hK
  let e : K → (ℕ → ℝ) := fun p n => p.val (d n)
  have hc : Continuous e := continuous_pi fun n =>
    (continuous_eval_const (d n)).comp continuous_subtype_val
  have he : MeasurableEmbedding e :=
    (hc.isClosedEmbedding (dense_evaluations_injective d hd K)).measurableEmbedding
  exact he.measurable_comp_iff.symm.trans measurable_pi_iff

end CountableTests

section Composite

variable {T S : Type*} [MetricSpace T] [CompactSpace T]
  [SecondCountableTopology T] [MeasurableSpace T] [BorelSpace T]
  [MeasurableSpace S]

local instance : MeasurableSpace C(T, ℝ) := borel _
local instance : BorelSpace C(T, ℝ) := ⟨rfl⟩

/-- Joint evaluation of a measurable payoff-profile path and a measurable type
path is measurable. -/
theorem measurable_profile_evaluation (g : S → C(T, ℝ)) (hg : Measurable g)
    (τ : S → T) (hτ : Measurable τ) : Measurable (fun s => g s (τ s)) := by
  exact continuous_eval.measurable.comp (hg.prodMk hτ)

/-- In particular, reindexing the selected profiles by any measurable shift
preserves measurable deviation payoffs. -/
theorem measurable_shifted_evaluation (g : T → C(T, ℝ)) (hg : Measurable g)
    (σ τ : S → T) (hσ : Measurable σ) (hτ : Measurable τ) :
    Measurable (fun s => g (σ s) (τ s)) :=
  measurable_profile_evaluation (g ∘ σ) (hg.comp hσ) τ hτ

/-- Uniformly bounded measurable shifted evaluations are integrable on every
set of finite measure. -/
theorem integrableOn_shifted_evaluation (μ : Measure S) (E : Set S)
    (hmE : MeasurableSet E) (hE : μ E < ∞) (g : T → C(T, ℝ)) (hg : Measurable g)
    (σ τ : S → T) (hσ : Measurable σ) (hτ : Measurable τ)
    (B : ℝ) (hB : ∀ s ∈ E, ‖g (σ s) (τ s)‖ ≤ B) :
    IntegrableOn (fun s => g (σ s) (τ s)) E μ := by
  exact IntegrableOn.of_bound hE
    (measurable_shifted_evaluation g hg σ τ hσ hτ).aestronglyMeasurable B (ae_restrict_of_forall_mem hmE hB)

end Composite

section ArbitraryMeasurableActions

variable {A S T : Type*} [MeasurableSpace A] [MeasurableSpace S]
  [TopologicalSpace T] [TopologicalSpace.MetrizableSpace T] [SecondCountableTopology T]
  [MeasurableSpace T] [OpensMeasurableSpace T]

/-- A sufficient condition with no topology, separability or Standard Borel
assumption on the action space: measurable fixed-type sections, continuous
fixed-action sections on any second-countable metrizable type space, and a
measurable chosen rule. -/
theorem measurable_payoff_composite (f : A → T → ℝ)
    (hc : ∀ a, Continuous (f a)) (hm : ∀ t, Measurable (fun a => f a t))
    (X : S → A) (hX : Measurable X) (τ : S → T) (hτ : Measurable τ) :
    Measurable (fun s => f (X s) (τ s)) := by
  have hj : Measurable (Function.uncurry (fun t a => f a t)) :=
    measurable_uncurry_of_continuous_of_measurable hc hm
  exact hj.comp (hτ.prodMk hX)

end ArbitraryMeasurableActions

end Envelope
