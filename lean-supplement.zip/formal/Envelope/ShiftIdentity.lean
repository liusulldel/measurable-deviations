import Mathlib.Analysis.Calculus.ParametricIntervalIntegral
import Mathlib.MeasureTheory.Integral.IntervalIntegral.FundThmCalculus
import Mathlib.Tactic

/-! A genuine differentiation identity for shifted selected payoffs. The selected
payoff `H u v` is the payoff at type `v` of the action selected at `u`. Joint
measurability is imposed on these observable payoffs, not on action labels.
The real-line formulation avoids artificial endpoint extension conventions. -/

open Set MeasureTheory Filter Topology
open scoped Interval NNReal

namespace Envelope

private theorem quadratic_error_hasDerivAt_zero (E : ℝ → ℝ) (L : ℝ)
    (h0 : E 0 = 0) (hbound : ∀ h, ‖E h‖ ≤ L * |h| * |h|) :
    HasDerivAt E 0 0 := by
  rw [hasDerivAt_iff_isLittleO]
  simp only [h0, sub_zero, smul_zero]
  apply Asymptotics.IsLittleO.of_bound
  intro ε hε
  have hc : ContinuousAt (fun h : ℝ => L * |h|) 0 := by fun_prop
  have he : ∀ᶠ h : ℝ in 𝓝 0, L * |h| < ε :=
    hc.eventually (gt_mem_nhds (by simpa using hε))
  filter_upwards [he] with h hh
  simp only [Real.norm_eq_abs]
  exact (hbound h).trans (mul_le_mul_of_nonneg_right hh.le (abs_nonneg h))

section Shift

variable (H : ℝ → ℝ → ℝ) (D : ℝ → ℝ) (L : ℝ≥0)
  (hH : Measurable (Function.uncurry H))
  (hLip : ∀ u, LipschitzWith L (H u))
  (hV : Continuous (fun u => H u u))

include hH in
private theorem shifted_type_measurable (m : ℝ) :
    Measurable (fun u => H u (u - m)) :=
  hH.comp (measurable_id.prodMk (measurable_id.sub_const m))

include hLip in
private theorem shifted_type_distance (m u : ℝ) :
    ‖H u (u - m) - H u u‖ ≤ (L : ℝ) * |m| := by
  simpa [dist_eq_norm, Real.norm_eq_abs] using (hLip u).dist_le_mul (u - m) u

include hH hLip hV in
private theorem shifted_type_integrable (m a b : ℝ) :
    IntervalIntegrable (fun u => H u (u - m)) volume a b := by
  have hb : Continuous (fun u => ‖H u u‖ + (L : ℝ) * |m|) :=
    hV.norm.add continuous_const
  apply (hb.intervalIntegrable a b).mono_fun'
    (shifted_type_measurable H hH m).aestronglyMeasurable
  exact Eventually.of_forall fun u => by
    calc
      ‖H u (u - m)‖ ≤ ‖H u (u - m) - H u u‖ + ‖H u u‖ :=
        norm_le_norm_sub_add _ _
      _ ≤ (L : ℝ) * |m| + ‖H u u‖ :=
        by linarith [shifted_type_distance H L hLip m u]
      _ = ‖H u u‖ + (L : ℝ) * |m| := add_comm _ _

include hLip in
private theorem boundary_error_derivative (c : ℝ) :
    HasDerivAt (fun m => ∫ u in c..c + m, H u (u - m) - H u u) 0 0 := by
  apply quadratic_error_hasDerivAt_zero _ (L : ℝ)
  · simp
  · intro m
    simpa using intervalIntegral.norm_integral_le_of_norm_le_const
      (a := c) (b := c + m)
      (fun u _ => shifted_type_distance H L hLip m u)

include hH hLip hV in
private theorem boundary_derivative (c : ℝ) :
    HasDerivAt (fun m => ∫ u in c..c + m, H u (u - m)) (H c c) 0 := by
  have hmain : HasDerivAt (fun m => ∫ u in c..c + m, H u u) (H c c) 0 := by
    have hf := intervalIntegral.integral_hasDerivAt_right
      (hV.intervalIntegrable c c) hV.stronglyMeasurable.stronglyMeasurableAtFilter
      hV.continuousAt
    have hf' : HasDerivAt (fun v => ∫ u in c..v, H u u) (H c c) (c + 0) := by
      simpa using hf
    simpa using hf'.comp 0 ((hasDerivAt_id (0 : ℝ)).const_add c)
  have hsum := hmain.add (boundary_error_derivative H L hLip c)
  convert hsum using 1
  · ext m
    simp only [Pi.add_apply]
    rw [intervalIntegral.integral_sub
      (shifted_type_integrable H L hH hLip hV m c (c + m))
      (hV.intervalIntegrable c (c + m))]
    ring
  · simp

include hH in
/-- Diagonal derivatives are measurable; no measurable-derivative assumption is
needed once the selected payoff kernel is jointly measurable. -/
theorem measurable_diagonal_derivative
    (hD : ∀ u, HasDerivAt (H u) (D u) u) : Measurable D := by
  let step : ℕ → ℝ := fun n => 1 / ((n : ℝ) + 1)
  have hs : Tendsto step atTop (𝓝[≠] (0 : ℝ)) := by
    refine tendsto_nhdsWithin_iff.mpr ⟨tendsto_one_div_add_atTop_nhds_zero_nat, ?_⟩
    exact Eventually.of_forall fun n => by
      change (1 / ((n : ℝ) + 1)) ≠ 0
      exact one_div_ne_zero (by positivity)
  apply measurable_of_tendsto_metrizable
    (f := fun n u => (step n)⁻¹ * (H u (u + step n) - H u u))
  · intro n
    exact measurable_const.mul
      ((hH.comp (measurable_id.prodMk (measurable_id.add_const (step n)))).sub
        (hH.comp (measurable_id.prodMk measurable_id)))
  · apply tendsto_pi_nhds.mpr
    intro u
    simpa only [smul_eq_mul] using (hD u).tendsto_slope_zero.comp hs

include hH in
/-- The diagonal derivative only needs to exist on the interval being integrated. -/
theorem aestronglyMeasurable_diagonal_derivative_on (a b : ℝ)
    (hD : ∀ u ∈ uIcc a b, HasDerivAt (H u) (D u) u) :
    AEStronglyMeasurable D (volume.restrict (Ι a b)) := by
  let step : ℕ → ℝ := fun n => 1 / ((n : ℝ) + 1)
  have hs : Tendsto step atTop (𝓝[≠] (0 : ℝ)) := by
    refine tendsto_nhdsWithin_iff.mpr ⟨tendsto_one_div_add_atTop_nhds_zero_nat, ?_⟩
    exact Eventually.of_forall fun n => by
      change (1 / ((n : ℝ) + 1)) ≠ 0
      exact one_div_ne_zero (by positivity)
  have hlim : AEMeasurable D (volume.restrict (Ι a b)) := by
    apply aemeasurable_of_tendsto_metrizable_ae atTop
      (f := fun n u => (step n)⁻¹ * (H u (u + step n) - H u u))
    · intro n
      exact (measurable_const.mul
        ((hH.comp (measurable_id.prodMk (measurable_id.add_const (step n)))).sub
          (hH.comp (measurable_id.prodMk measurable_id)))).aemeasurable
    · filter_upwards [ae_restrict_mem measurableSet_uIoc] with u hu
      simpa only [smul_eq_mul] using
        (hD u (uIoc_subset_uIcc hu)).tendsto_slope_zero.comp hs
  exact hlim.aestronglyMeasurable

include hH hLip hV in
/-- Every shifted-payoff integral in the identity is genuinely integrable. -/
theorem intervalIntegrable_shifted_payoff (m r t : ℝ) :
    IntervalIntegrable (fun s => H (s + m) s) volume r t := by
  simpa using (shifted_type_integrable H L hH hLip hV m (r + m) (t + m)).comp_add_right m

include hH hLip hV in
private theorem fixed_interval_derivative
    (a b : ℝ) (hD : ∀ u ∈ uIcc a b, HasDerivAt (H u) (D u) u) :
    HasDerivAt (fun m => ∫ u in a..b, H u (u - m))
      (-(∫ u in a..b, D u)) 0 := by
  have hdM := aestronglyMeasurable_diagonal_derivative_on H D hH a b hD
  have hdiff : ∀ u ∈ uIcc a b, HasDerivAt (fun m => H u (u - m)) (-D u) 0 := by
    intro u hu
    simpa using (hD u hu).comp_of_eq 0
      ((hasDerivAt_id (0 : ℝ)).const_sub u) (by simp)
  have hlip : ∀ u, LipschitzWith L (fun m => H u (u - m)) := by
    intro u
    rw [lipschitzWith_iff_dist_le_mul]
    intro x y
    have he : (u - x) - (u - y) = -(x - y) := by ring
    simpa only [Real.dist_eq, he, abs_neg] using
      (hLip u).dist_le_mul (u - x) (u - y)
  have hi := intervalIntegral.hasDerivAt_integral_of_dominated_loc_of_lip
    (F := fun m u => H u (u - m)) (F' := fun u => -D u)
    (x₀ := (0 : ℝ)) (s := Set.univ) (bound := fun _ => (L : ℝ))
    (a := a) (b := b) (μ := volume) (Filter.univ_mem)
    (Eventually.of_forall fun m => (shifted_type_measurable H hH m).aestronglyMeasurable)
    (by simpa using hV.intervalIntegrable a b)
    hdM.neg
    (Eventually.of_forall fun u _ => by
      simpa using (hlip u).lipschitzOnWith (s := Set.univ))
    (intervalIntegrable_const)
    (Eventually.of_forall fun u hu => hdiff u (uIoc_subset_uIcc hu))
  simpa using hi.2

include hH hLip hV in
/-- The corrected shifted-payoff identity. The hypotheses are independently
checkable properties of the payoff kernel, not the desired identity itself. -/
theorem hasDerivAt_shifted_integral_local
    (r t : ℝ) (hD : ∀ u ∈ uIcc r t, HasDerivAt (H u) (D u) u) :
    HasDerivAt (fun m => ∫ s in r..t, H (s + m) s)
      (H t t - H r r - ∫ s in r..t, D s) 0 := by
  have hk := fixed_interval_derivative H D L hH hLip hV r t hD
  have ht := boundary_derivative H L hH hLip hV t
  have hr := boundary_derivative H L hH hLip hV r
  have hall := (hk.add ht).sub hr
  convert hall using 1
  · ext m
    simp only [Pi.add_apply, Pi.sub_apply]
    have htransport : (∫ s in r..t, H (s + m) s) =
        ∫ u in r + m..t + m, H u (u - m) := by
      simpa using intervalIntegral.integral_comp_add_right (fun u => H u (u - m)) m
    rw [htransport]
    have he := intervalIntegral.integral_interval_sub_interval_comm'
      (shifted_type_integrable H L hH hLip hV m (r + m) (t + m))
      (shifted_type_integrable H L hH hLip hV m r t)
      (shifted_type_integrable H L hH hLip hV m (r + m) r)
    linarith
  · ring

include hH hLip hV in
/-- Local form of the repaired OFOC/envelope equivalence, requiring diagonal
smoothness only on the interval whose deviations are aggregated. -/
theorem shifted_OFOC_iff_envelope_increment_local
    (r t : ℝ) (hD : ∀ u ∈ uIcc r t, HasDerivAt (H u) (D u) u) :
    HasDerivAt (fun m => ∫ s in r..t, H (s + m) s) 0 0 ↔
      H t t - H r r = ∫ s in r..t, D s := by
  have hd := hasDerivAt_shifted_integral_local H D L hH hLip hV r t hD
  constructor
  · intro hz
    have he := hd.unique hz
    linarith
  · intro he
    simpa [he] using hd

include hH hLip hV in
/-- Global-derivative specialization of the local identity. -/
theorem hasDerivAt_shifted_integral
    (hD : ∀ u, HasDerivAt (H u) (D u) u) (r t : ℝ) :
    HasDerivAt (fun m => ∫ s in r..t, H (s + m) s)
      (H t t - H r r - ∫ s in r..t, D s) 0 :=
  hasDerivAt_shifted_integral_local H D L hH hLip hV r t (fun u _ => hD u)

include hH hLip hV in
/-- On any interval, the repaired OFOC is exactly the envelope increment. -/
theorem shifted_OFOC_iff_envelope_increment
    (hD : ∀ u, HasDerivAt (H u) (D u) u) (r t : ℝ) :
    HasDerivAt (fun m => ∫ s in r..t, H (s + m) s) 0 0 ↔
      H t t - H r r = ∫ s in r..t, D s := by
  have hd := hasDerivAt_shifted_integral H D L hH hLip hV hD r t
  constructor
  · intro hz
    have he := hd.unique hz
    linarith
  · intro he
    simpa [he] using hd

end Shift

end Envelope
