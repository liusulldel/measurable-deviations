import Envelope.MeasurableProfiles
import Envelope.ShiftIdentity
import Envelope.EnvelopeConsequences
import Mathlib.Topology.Order.ProjIcc
import Mathlib.Analysis.Calculus.FDeriv.Measurable

/-! The compact unit-interval payoff representation and the real-variable
shift identity use the same functions near every interior integration interval.
Clamping is only an extension convention outside the economically meaningful domain. -/

open Set MeasureTheory Filter Topology
open scoped NNReal

namespace Envelope.IntervalBridge

abbrev T := Icc (0 : ℝ) 1

local instance : MeasurableSpace C(T, ℝ) := borel _
local instance : BorelSpace C(T, ℝ) := ⟨rfl⟩

noncomputable def clamp : ℝ → T := projIcc 0 1 (by norm_num)

theorem continuous_clamp : Continuous clamp := continuous_projIcc

theorem lipschitz_clamp : LipschitzWith 1 clamp := LipschitzWith.projIcc (by norm_num)

@[simp] theorem clamp_coe (u : T) : clamp u = u := by
  simp [clamp]

noncomputable def kernel (g : T → C(T, ℝ)) (u v : ℝ) : ℝ := g (clamp u) (clamp v)

theorem kernel_measurable (g : T → C(T, ℝ)) (hg : Measurable g) :
    Measurable (Function.uncurry (kernel g)) := by
  exact measurable_profile_evaluation
    (fun z : ℝ × ℝ => g (clamp z.1))
    (hg.comp (continuous_clamp.measurable.comp measurable_fst))
    (fun z : ℝ × ℝ => clamp z.2)
    (continuous_clamp.measurable.comp measurable_snd)

theorem kernel_lipschitz (g : T → C(T, ℝ)) (L : ℝ≥0)
    (hL : ∀ u, LipschitzWith L (g u)) :
    ∀ u, LipschitzWith L (kernel g u) := by
  intro u
  simpa [kernel] using (hL (clamp u)).comp lipschitz_clamp

theorem kernel_diagonal_continuous (g : T → C(T, ℝ))
    (hV : Continuous (fun u : T => g u u)) :
    Continuous (fun u : ℝ => kernel g u u) := hV.comp continuous_clamp

/-- On admissible types the extension is exactly the original payoff. -/
@[simp] theorem kernel_on_interval (g : T → C(T, ℝ)) (u v : T) :
    kernel g u v = g u v := by simp [kernel]

/-- Every interior integration window has a neighborhood of admissible shifts. -/
theorem shifted_types_admissible {r t : ℝ}
    (hr : 0 < r) (ht : t < 1) :
    ∀ᶠ h : ℝ in 𝓝 0, ∀ s ∈ Icc r t, s + h ∈ Icc (0 : ℝ) 1 := by
  have hpos : 0 < min r (1 - t) := lt_min hr (by linarith)
  filter_upwards [Metric.ball_mem_nhds (0 : ℝ) hpos] with h hh
  have hha : |h| < min r (1 - t) := by simpa [Metric.mem_ball, Real.dist_eq] using hh
  obtain ⟨hlo, hhi⟩ := abs_lt.mp hha
  intro s hs
  constructor <;> linarith [min_le_left r (1 - t), min_le_right r (1 - t), hs.1, hs.2]

/-- The repaired identity for actual compact-interval profiles. Interior
derivatives are stated for the clamped extension, which agrees locally with
the original type profile. No derivative at an interval endpoint is assumed. -/
theorem interval_profile_shift_identity (g : T → C(T, ℝ)) (D : ℝ → ℝ)
    (L : ℝ≥0) (hg : Measurable g) (hL : ∀ u, LipschitzWith L (g u))
    (hV : Continuous (fun u : T => g u u))
    (hD : ∀ u ∈ Ioo (0 : ℝ) 1, HasDerivAt (kernel g u) (D u) u)
    (r t : ℝ) (hr : 0 < r) (hrt : r ≤ t) (ht : t < 1) :
    HasDerivAt (fun h => ∫ s in r..t, kernel g (s + h) s)
      (kernel g t t - kernel g r r - ∫ s in r..t, D s) 0 := by
  apply hasDerivAt_shifted_integral_local (kernel g) D L
    (kernel_measurable g hg) (kernel_lipschitz g L hL)
    (kernel_diagonal_continuous g hV) r t
  intro u hu
  rw [uIcc_of_le hrt] at hu
  exact hD u ⟨lt_of_lt_of_le hr hu.1, lt_of_le_of_lt hu.2 ht⟩

/-- The exact OFOC/envelope equivalence on the repaired compact interval. -/
theorem interval_profile_OFOC_iff (g : T → C(T, ℝ)) (D : ℝ → ℝ)
    (L : ℝ≥0) (hg : Measurable g) (hL : ∀ u, LipschitzWith L (g u))
    (hV : Continuous (fun u : T => g u u))
    (hD : ∀ u ∈ Ioo (0 : ℝ) 1, HasDerivAt (kernel g u) (D u) u)
    (r t : ℝ) (hr : 0 < r) (hrt : r ≤ t) (ht : t < 1) :
    HasDerivAt (fun h => ∫ s in r..t, kernel g (s + h) s) 0 0 ↔
      kernel g t t - kernel g r r = ∫ s in r..t, D s := by
  have hd := interval_profile_shift_identity g D L hg hL hV hD r t hr hrt ht
  constructor
  · intro hz
    have he := hd.unique hz
    linarith
  · intro he
    simpa [he] using hd

/-- The diagonal type derivative, with the endpoint and exterior values zero. -/
noncomputable def diagonalDerivative (g : T → C(T, ℝ)) (u : ℝ) : ℝ :=
  (Ioo (0 : ℝ) 1).indicator (fun v => deriv (kernel g v) v) u

/-- Measurability of the actual derivative is a conclusion, not an input. -/
theorem diagonalDerivative_measurable (g : T → C(T, ℝ)) (hg : Measurable g) :
    Measurable (diagonalDerivative g) := by
  have hc : Continuous (Function.uncurry (fun p : C(T, ℝ) => fun u : ℝ => p (clamp u))) :=
    continuous_eval.comp (continuous_fst.prodMk (continuous_clamp.comp continuous_snd))
  have hm := measurable_deriv_with_param hc
  have hh := hm.comp ((hg.comp continuous_clamp.measurable).prodMk measurable_id)
  exact hh.indicator measurableSet_Ioo

theorem diagonalDerivative_bound (g : T → C(T, ℝ)) (L : ℝ≥0)
    (hL : ∀ u, LipschitzWith L (g u)) (v : ℝ) :
    ‖diagonalDerivative g v‖ ≤ (L : ℝ) := by
  classical
  by_cases hv : v ∈ Ioo (0 : ℝ) 1
  · simpa [diagonalDerivative, hv] using
      norm_deriv_le_of_lipschitz (x₀ := v) (kernel_lipschitz g L hL v)
  · simp [diagonalDerivative, hv]

theorem diagonalDerivative_intervalIntegrable (g : T → C(T, ℝ)) (L : ℝ≥0)
    (hg : Measurable g) (hL : ∀ u, LipschitzWith L (g u)) (a b : ℝ) :
    IntervalIntegrable (diagonalDerivative g) volume a b := by
  apply (intervalIntegrable_const (c := (L : ℝ))).mono_fun'
    (diagonalDerivative_measurable g hg).aestronglyMeasurable
  exact Eventually.of_forall (diagonalDerivative_bound g L hL)

/-- Differentiability only at the selected diagonal points suffices. -/
theorem hasDerivAt_diagonalDerivative (g : T → C(T, ℝ))
    (hDiff : ∀ u ∈ Ioo (0 : ℝ) 1, DifferentiableAt ℝ (kernel g u) u)
    (u : ℝ) (hu : u ∈ Ioo (0 : ℝ) 1) :
    HasDerivAt (kernel g u) (diagonalDerivative g u) u := by
  simpa [diagonalDerivative, hu] using (hDiff u hu).hasDerivAt

/-- Fully instantiated interval identity, including existence of ordinary
shifted integrals and the integrability of its derived envelope integrand. -/
theorem repaired_interval_identity (g : T → C(T, ℝ)) (L : ℝ≥0)
    (hg : Measurable g) (hL : ∀ u, LipschitzWith L (g u))
    (hV : Continuous (fun u : T => g u u))
    (hDiff : ∀ u ∈ Ioo (0 : ℝ) 1, DifferentiableAt ℝ (kernel g u) u)
    (r t : ℝ) (hr : 0 < r) (hrt : r ≤ t) (ht : t < 1) :
    (∀ h, IntervalIntegrable (fun s => kernel g (s + h) s) volume r t) ∧
      IntervalIntegrable (diagonalDerivative g) volume r t ∧
      HasDerivAt (fun h => ∫ s in r..t, kernel g (s + h) s)
        (kernel g t t - kernel g r r - ∫ s in r..t, diagonalDerivative g s) 0 := by
  refine ⟨?_, diagonalDerivative_intervalIntegrable g L hg hL r t, ?_⟩
  · intro h
    exact intervalIntegrable_shifted_payoff (kernel g) L
      (kernel_measurable g hg) (kernel_lipschitz g L hL)
      (kernel_diagonal_continuous g hV) h r t
  · exact interval_profile_shift_identity g (diagonalDerivative g) L hg hL hV
      (hasDerivAt_diagonalDerivative g hDiff) r t hr hrt ht

/-- The complete repaired converse on `[0,1]`, including endpoint extension
and absolute continuity. All derivative measurability and integrability
obligations are derived internally. -/
theorem repaired_converse (g : T → C(T, ℝ)) (L : ℝ≥0)
    (hg : Measurable g) (hL : ∀ u, LipschitzWith L (g u))
    (hV : Continuous (fun u : T => g u u))
    (hDiff : ∀ u ∈ Ioo (0 : ℝ) 1, DifferentiableAt ℝ (kernel g u) u) :
    (∀ r t : ℝ, 0 < r → r < t → t < 1 →
      HasDerivAt (fun h => ∫ s in r..t, kernel g (s + h) s) 0 0) ↔
    ((∀ r ∈ Icc (0 : ℝ) 1, ∀ t ∈ Icc (0 : ℝ) 1,
        kernel g t t - kernel g r r = ∫ s in r..t, diagonalDerivative g s) ∧
      AbsolutelyContinuousOnInterval (fun u => kernel g u u) 0 1) := by
  have hc : ContinuousOn (fun u => kernel g u u) (Icc (0 : ℝ) 1) :=
    (kernel_diagonal_continuous g hV).continuousOn
  have hi := diagonalDerivative_intervalIntegrable g L hg hL 0 1
  have hb : ∀ u ∈ Icc (0 : ℝ) 1, ‖diagonalDerivative g u‖ ≤ (L : ℝ) :=
    fun u _ => diagonalDerivative_bound g L hL u
  have hd := hasDerivAt_diagonalDerivative g hDiff
  constructor
  · intro hO
    have hEnv := interior_envelope_of_ordered (fun u => kernel g u u)
      (diagonalDerivative g) (fun r hr t ht hrt =>
        (interval_profile_OFOC_iff g (diagonalDerivative g) L hg hL hV hd
          r t hr.1 hrt.le ht.2).mp (hO r t hr.1 hrt ht.2))
    exact ⟨envelope_extends_to_endpoints _ _ hc hi hEnv,
      envelope_absolutelyContinuous_of_interior _ _ L hc hi hb hEnv⟩
  · rintro ⟨hEnv, _⟩ r t hr hrt ht
    apply (interval_profile_OFOC_iff g (diagonalDerivative g) L hg hL hV hd
      r t hr hrt.le ht).mpr
    exact hEnv r ⟨hr.le, (hrt.trans ht).le⟩ t ⟨(hr.trans hrt).le, ht.le⟩

end Envelope.IntervalBridge
