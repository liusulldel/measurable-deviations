import Mathlib.Analysis.Calculus.Deriv.Pow
import Mathlib.Analysis.Calculus.Deriv.Add
import Mathlib.Analysis.Calculus.Deriv.Mul
import Mathlib.MeasureTheory.Measure.Lebesgue.Basic
import Mathlib.MeasureTheory.Measure.Haar.Basic
import Mathlib.MeasureTheory.Integral.Bochner.Basic
import Mathlib.MeasureTheory.Function.AbsolutelyContinuous
import Mathlib.Topology.MetricSpace.Lipschitz
import Mathlib.Tactic

/-!
# The quadratic-null construction

All algebra and differentiation are on the ambient action space `ℝ × ℝ`.
Interval hypotheses enter only uniform estimates. Nonmeasurability means failure
of `NullMeasurableSet` for Lebesgue volume, including its completion.
-/

open MeasureTheory Set

namespace Envelope.QuadraticNull

noncomputable def payoff (A : Set ℝ) (x : ℝ × ℝ) (t : ℝ) : ℝ :=
  -(A.indicator (fun _ => (1 : ℝ)) x.2) * (t - x.1) ^ 2

def diagonal (t : ℝ) : ℝ × ℝ := (t, t)

@[simp] theorem payoff_diagonal (A : Set ℝ) (t : ℝ) :
    payoff A (diagonal t) t = 0 := by
  simp [payoff, diagonal]

theorem payoff_nonpos (A : Set ℝ) (x : ℝ × ℝ) (t : ℝ) :
    payoff A x t ≤ 0 := by
  classical
  by_cases h : x.2 ∈ A
  · simp only [payoff, indicator_of_mem h, neg_mul, one_mul]
    exact neg_nonpos.mpr (sq_nonneg _)
  · simp [payoff, h]

theorem diagonal_optimal (A : Set ℝ) (t : ℝ) (x : ℝ × ℝ) :
    payoff A x t ≤ payoff A (diagonal t) t := by
  simpa using payoff_nonpos A x t

theorem hasDerivAt_payoff (A : Set ℝ) (x : ℝ × ℝ) (t : ℝ) :
    HasDerivAt (payoff A x)
      (-2 * (t - x.1) * A.indicator (fun _ => (1 : ℝ)) x.2) t := by
  convert ((((hasDerivAt_id t).sub_const x.1).pow 2).const_mul
    (-(A.indicator (fun _ => (1 : ℝ)) x.2))) using 1
  simp
  ring

theorem derivative_on_diagonal (A : Set ℝ) (t : ℝ) :
    HasDerivAt (payoff A (diagonal t)) 0 t := by
  simpa [diagonal] using hasDerivAt_payoff A (diagonal t) t

@[simp] theorem deriv_on_diagonal (A : Set ℝ) (t : ℝ) :
    deriv (payoff A (diagonal t)) t = 0 :=
  (derivative_on_diagonal A t).deriv

/-- The envelope identity holds on every subinterval. -/
theorem envelope_formula (A : Set ℝ) (a b : ℝ) :
    payoff A (diagonal b) b = payoff A (diagonal a) a +
      ∫ s in a..b, deriv (payoff A (diagonal s)) s := by
  simp

theorem value_hasDerivAt (A : Set ℝ) (t : ℝ) :
    HasDerivAt (fun s => payoff A (diagonal s) s) 0 t := by
  simpa using hasDerivAt_const t (0 : ℝ)

/-- Fixed actions have uniformly bounded type derivatives on the unit interval. -/
theorem derivative_bound (A : Set ℝ) (x : ℝ × ℝ) (t : ℝ)
    (hu : x.1 ∈ Icc (0 : ℝ) 1) (ht : t ∈ Icc (0 : ℝ) 1) :
    |(-2 * (t - x.1) * A.indicator (fun _ => (1 : ℝ)) x.2)| ≤ 2 := by
  classical
  by_cases h : x.2 ∈ A
  · simp only [indicator_of_mem h, mul_one]
    rw [abs_le]
    constructor <;> nlinarith [hu.1, hu.2, ht.1, ht.2]
  · simp [h]

/-- All type sections are 2-Lipschitz on `[0,1]`, uniformly over unit-square actions. -/
theorem payoff_lipschitz_bound (A : Set ℝ) (x : ℝ × ℝ) (s t : ℝ)
    (hu : x.1 ∈ Icc (0 : ℝ) 1) (hs : s ∈ Icc (0 : ℝ) 1)
    (ht : t ∈ Icc (0 : ℝ) 1) :
    |payoff A x s - payoff A x t| ≤ 2 * |s - t| := by
  classical
  by_cases h : x.2 ∈ A
  · have hb : |s + t - 2 * x.1| ≤ 2 := by
      rw [abs_le]
      constructor <;> linarith [hu.1, hu.2, hs.1, hs.2, ht.1, ht.2]
    have he : payoff A x s - payoff A x t = -(s - t) * (s + t - 2 * x.1) := by
      simp [payoff, h]
      ring
    rw [he, abs_mul, abs_neg, mul_comm]
    exact mul_le_mul_of_nonneg_right hb (abs_nonneg _)
  · simp [payoff, h, mul_nonneg (by norm_num : (0 : ℝ) ≤ 2) (abs_nonneg (s-t))]

/-- The uniform estimate expressed with Mathlib's Lipschitz API. -/
theorem payoff_lipschitzOnWith (A : Set ℝ) (x : ℝ × ℝ)
    (hu : x.1 ∈ Icc (0 : ℝ) 1) :
    LipschitzOnWith 2 (payoff A x) (Icc (0 : ℝ) 1) := by
  rw [lipschitzOnWith_iff_dist_le_mul]
  intro s hs t ht
  simpa only [Real.dist_eq, NNReal.coe_ofNat] using payoff_lipschitz_bound A x s t hu hs ht

/-- The fixed-action payoff sections are absolutely continuous. -/
theorem payoff_absolutelyContinuous (A : Set ℝ) (x : ℝ × ℝ)
    (hu : x.1 ∈ Icc (0 : ℝ) 1) :
    AbsolutelyContinuousOnInterval (payoff A x) 0 1 := by
  apply LipschitzOnWith.absolutelyContinuousOnInterval (K := 2)
  simpa only [uIcc_of_le (by norm_num : (0 : ℝ) ≤ 1)] using payoff_lipschitzOnWith A x hu

/-- The selected value is absolutely continuous, as it is identically zero. -/
theorem value_absolutelyContinuous (A : Set ℝ) :
    AbsolutelyContinuousOnInterval (fun t => payoff A (diagonal t) t) 0 1 := by
  simpa using (LipschitzWith.const (0 : ℝ)).lipschitzOnWith.absolutelyContinuousOnInterval
    (a := (0 : ℝ)) (b := (1 : ℝ))

/-- A uniform absolute-continuity estimate, permitting a different action on each interval.
Disjointness of the intervals is unnecessary for this stronger estimate. -/
theorem absolute_equicontinuity_estimate (A : Set ℝ) {ι : Type*}
    (I : Finset ι) (x : ι → ℝ × ℝ) (s t : ι → ℝ) (ε : ℝ)
    (hu : ∀ i ∈ I, (x i).1 ∈ Icc (0 : ℝ) 1)
    (hs : ∀ i ∈ I, s i ∈ Icc (0 : ℝ) 1)
    (ht : ∀ i ∈ I, t i ∈ Icc (0 : ℝ) 1)
    (hδ : ∑ i ∈ I, |s i - t i| < ε / 2) :
    ∑ i ∈ I, |payoff A (x i) (s i) - payoff A (x i) (t i)| < ε := by
  have hle : ∑ i ∈ I, |payoff A (x i) (s i) - payoff A (x i) (t i)| ≤
      2 * ∑ i ∈ I, |s i - t i| := by
    rw [Finset.mul_sum]
    exact Finset.sum_le_sum fun i hi => payoff_lipschitz_bound A (x i) (s i) (t i)
      (hu i hi) (hs i hi) (ht i hi)
  linarith

/-- The shifted action remains in the unit square throughout the fixed integration interval. -/
theorem shifted_action_admissible (s m : ℝ)
    (hs : s ∈ Icc (1 / 4 : ℝ) (3 / 4 : ℝ)) (hm : |m| < 1 / 12) :
    diagonal (s + m) ∈ (Icc (0 : ℝ) 1) ×ˢ (Icc (0 : ℝ) 1) := by
  obtain ⟨hm₁, hm₂⟩ := abs_lt.mp hm
  have ht : s + m ∈ Icc (0 : ℝ) 1 := by constructor <;> linarith [hs.1, hs.2]
  exact ⟨ht, ht⟩

/-- The decisive off-diagonal formula. -/
theorem shifted_payoff (A : Set ℝ) (m s : ℝ) :
    payoff A (diagonal (s + m)) s =
      ((fun z : ℝ => z + m) ⁻¹' A).indicator (fun _ => -(m ^ 2)) s := by
  classical
  by_cases h : s + m ∈ A
  · simp [payoff, diagonal, h]
  · simp [payoff, diagonal, h]

/-- Translation preserves failure of Lebesgue measurability, including completion. -/
theorem translate_not_nullMeasurable (A : Set ℝ)
    (hA : ¬ NullMeasurableSet A volume) (m : ℝ) :
    ¬ NullMeasurableSet ((fun z : ℝ => z + m) ⁻¹' A) volume := by
  intro h
  have h' := h.preimage (measurePreserving_add_right volume (-m)).quasiMeasurePreserving
  apply hA
  simpa only [preimage_preimage, Function.comp_def, neg_add_cancel_right] using h'

/-- Localization corrects the draft's inference from global nonmeasurability
to nonmeasurability on an arbitrary integration interval. -/
theorem shifted_support_subset (A : Set ℝ)
    (hA : A ⊆ Icc (1 / 3 : ℝ) (2 / 3 : ℝ)) (m : ℝ)
    (hm : |m| < 1 / 12) :
    ((fun z : ℝ => z + m) ⁻¹' A) ⊆ Icc (1 / 4 : ℝ) (3 / 4 : ℝ) := by
  intro s hs
  obtain ⟨ha, hb⟩ := hA hs
  obtain ⟨hm₁, hm₂⟩ := abs_lt.mp hm
  constructor <;> linarith

/-- Every small nonzero deviation fails a.e. measurability on one fixed interior interval. -/
theorem shifted_payoff_not_aemeasurable (A : Set ℝ)
    (hA : A ⊆ Icc (1 / 3 : ℝ) (2 / 3 : ℝ))
    (hAn : ¬ NullMeasurableSet A volume) (m : ℝ)
    (hm : |m| < 1 / 12) (hm0 : m ≠ 0) :
    ¬ AEMeasurable (fun s => payoff A (diagonal (s + m)) s)
      (volume.restrict (Icc (1 / 4 : ℝ) (3 / 4 : ℝ))) := by
  intro h
  have hn : -(m ^ 2) ≠ 0 := neg_ne_zero.mpr (pow_ne_zero 2 hm0)
  letI : NeZero (-(m ^ 2)) := ⟨hn⟩
  have hi : AEMeasurable
      (((fun z : ℝ => z + m) ⁻¹' A).indicator (fun _ => -(m ^ 2)))
      (volume.restrict (Icc (1 / 4 : ℝ) (3 / 4 : ℝ))) := by
    simpa only [shifted_payoff] using h
  have hnm := (aemeasurable_indicator_const_iff (-(m ^ 2))).mp hi
  exact translate_not_nullMeasurable A hAn m
    ((nullMeasurableSet_restrict_of_subset (shifted_support_subset A hA m hm)).mp hnm)

/-- Lean's integral is totalized; failure of `Integrable` expresses the obstruction. -/
theorem shifted_payoff_not_integrable (A : Set ℝ)
    (hA : A ⊆ Icc (1 / 3 : ℝ) (2 / 3 : ℝ))
    (hAn : ¬ NullMeasurableSet A volume) (m : ℝ)
    (hm : |m| < 1 / 12) (hm0 : m ≠ 0) :
    ¬ Integrable (fun s => payoff A (diagonal (s + m)) s)
      (volume.restrict (Icc (1 / 4 : ℝ) (3 / 4 : ℝ))) := by
  intro h
  exact shifted_payoff_not_aemeasurable A hA hAn m hm hm0 h.aestronglyMeasurable.aemeasurable


/-- The usual shifted deviation quotient. -/
noncomputable def deviationQuotient (A : Set ℝ) (m s : ℝ) : ℝ :=
  (payoff A (diagonal (s + m)) s - payoff A (diagonal s) s) / m

/-- These quotients are pointwise dominated by `|m|`, despite being nonmeasurable. -/
theorem deviationQuotient_bound (A : Set ℝ) (m s : ℝ) :
    |deviationQuotient A m s| ≤ |m| := by
  classical
  by_cases hm : m = 0
  · simp [deviationQuotient, hm]
  by_cases hA : s + m ∈ A
  · have he : deviationQuotient A m s = -m := by
      simp [deviationQuotient, payoff, diagonal, hA]
      field_simp
    rw [he, abs_neg]
  · simp [deviationQuotient, payoff, diagonal, hA, abs_nonneg]

/-- Domination by a constant, even one tending to zero, does not supply measurability. -/
theorem deviationQuotient_not_aemeasurable (A : Set ℝ)
    (hA : A ⊆ Icc (1 / 3 : ℝ) (2 / 3 : ℝ))
    (hAn : ¬ NullMeasurableSet A volume) (m : ℝ)
    (hm : |m| < 1 / 12) (hm0 : m ≠ 0) :
    ¬ AEMeasurable (deviationQuotient A m)
      (volume.restrict (Icc (1 / 4 : ℝ) (3 / 4 : ℝ))) := by
  intro h
  apply shifted_payoff_not_aemeasurable A hA hAn m hm hm0
  have hh := h.mul (aemeasurable_const (b := m))
  simpa [deviationQuotient, hm0] using hh

/-! ## A genuine non-Lebesgue-measurable set inside the interior interval

A rational-equivalence transversal is selected within `[1/3,2/3]`.
The null case contradicts countable translation covering. The positive case
contradicts Steinhaus, since the difference set contains no nonzero rational.
-/

private def rationalSetoid : Setoid (Icc (1 / 3 : ℝ) (2 / 3 : ℝ)) where
  r x y := ∃ q : ℚ, (x : ℝ) - (y : ℝ) = q
  iseqv := {
    refl := fun x => ⟨0, by simp⟩
    symm := by
      rintro x y ⟨q, hq⟩
      exact ⟨-q, by push_cast; linarith⟩
    trans := by
      rintro x y z ⟨q, hq⟩ ⟨r, hr⟩
      exact ⟨q + r, by push_cast; linarith⟩ }

private noncomputable def vitaliSet : Set ℝ :=
  range (fun q : Quotient rationalSetoid => (q.out : ℝ))

private theorem vitaliSet_subset :
    vitaliSet ⊆ Icc (1 / 3 : ℝ) (2 / 3 : ℝ) := by
  rintro x ⟨q, rfl⟩
  exact q.out.property

private theorem vitaliSet_rational_unique {x y : ℝ}
    (hx : x ∈ vitaliSet) (hy : y ∈ vitaliSet)
    {q : ℚ} (hxy : x - y = q) : x = y := by
  obtain ⟨a, rfl⟩ := hx
  obtain ⟨b, rfl⟩ := hy
  have hab : a = b := Quotient.out_equiv_out.mp (show rationalSetoid a.out b.out from ⟨q, hxy⟩)
  rw [hab]

private theorem vitaliSet_cover :
    Icc (1 / 3 : ℝ) (2 / 3 : ℝ) ⊆
      ⋃ q : ℚ, (fun x : ℝ => x + q) ⁻¹' vitaliSet := by
  intro x hx
  let a : Icc (1 / 3 : ℝ) (2 / 3 : ℝ) := ⟨x, hx⟩
  obtain ⟨q, hq⟩ := Quotient.mk_out (s := rationalSetoid) a
  apply mem_iUnion.mpr
  refine ⟨q, ?_⟩
  change x + (q : ℝ) ∈ vitaliSet
  have he : x + (q : ℝ) = ((Quotient.mk rationalSetoid a).out : ℝ) := by
    change ((Quotient.mk rationalSetoid a).out : ℝ) - x = (q : ℝ) at hq
    linarith
  rw [he]
  exact mem_range_self (Quotient.mk rationalSetoid a)

private theorem vitaliSet_measure_ne_zero : volume vitaliSet ≠ 0 := by
  intro hz
  have hu : volume (⋃ q : ℚ, (fun x : ℝ => x + q) ⁻¹' vitaliSet) = 0 := by
    apply measure_iUnion_null
    intro q
    simpa using hz
  have hi := measure_mono_null vitaliSet_cover hu
  norm_num [Real.volume_Icc] at hi

private theorem vitaliSet_not_nullMeasurable : ¬ NullMeasurableSet vitaliSet volume := by
  intro h
  obtain ⟨B, hBA, hB, hBeq⟩ := h.exists_measurable_subset_ae_eq
  have hBp : 0 < volume B := by
    rw [measure_congr hBeq]
    exact bot_lt_iff_ne_bot.mpr vitaliSet_measure_ne_zero
  have hd := Measure.sub_mem_nhds_zero_of_addHaar_pos volume B hB hBp
  obtain ⟨ε, hε, hball⟩ := Metric.mem_nhds_iff.mp hd
  obtain ⟨q, hq0, hqε⟩ := exists_rat_btwn hε
  have hqball : (q : ℝ) ∈ Metric.ball (0 : ℝ) ε := by
    simpa only [Metric.mem_ball, Real.dist_eq, sub_zero, abs_of_pos hq0] using hqε
  obtain ⟨x, hx, y, hy, hxy⟩ := Set.mem_sub.mp (hball hqball)
  have hxy' := vitaliSet_rational_unique (hBA hx) (hBA hy) hxy
  have : (q : ℝ) = 0 := by linarith
  linarith

/-- There exists a genuinely non-Lebesgue-measurable subset of a fixed interior interval.
Only the standard classical choice principles used by Mathlib are required. -/
theorem exists_nonmeasurable_interior :
    ∃ A : Set ℝ, A ⊆ Icc (1 / 3 : ℝ) (2 / 3 : ℝ) ∧
      ¬ NullMeasurableSet A volume :=
  ⟨vitaliSet, vitaliSet_subset, vitaliSet_not_nullMeasurable⟩


/-- An unconditional witness to the complete quadratic-null construction.
The selected value and its envelope derivative vanish, all sections are uniformly
Lipschitz, and every sufficiently small nonzero deviation is nonintegrable. -/
theorem exists_quadratic_null :
    ∃ A : Set ℝ,
      A ⊆ Icc (1 / 3 : ℝ) (2 / 3 : ℝ) ∧
      (∀ t x, payoff A x t ≤ payoff A (diagonal t) t) ∧
      (∀ t, payoff A (diagonal t) t = 0) ∧
      (∀ t, HasDerivAt (payoff A (diagonal t)) 0 t) ∧
      (∀ x, x.1 ∈ Icc (0 : ℝ) 1 → LipschitzOnWith 2 (payoff A x) (Icc (0 : ℝ) 1)) ∧
      (∀ m, |m| < 1 / 12 → m ≠ 0 →
        ¬ Integrable (fun s => payoff A (diagonal (s + m)) s)
          (volume.restrict (Icc (1 / 4 : ℝ) (3 / 4 : ℝ)))) := by
  obtain ⟨A, hA, hAn⟩ := exists_nonmeasurable_interior
  exact ⟨A, hA, diagonal_optimal A, payoff_diagonal A, derivative_on_diagonal A,
    payoff_lipschitzOnWith A, shifted_payoff_not_integrable A hA hAn⟩

end Envelope.QuadraticNull


