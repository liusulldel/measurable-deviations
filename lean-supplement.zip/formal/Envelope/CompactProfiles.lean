import Mathlib.Topology.ContinuousMap.Bounded.ArzelaAscoli
import Mathlib.Topology.ContinuousMap.Compact
import Mathlib.Topology.Connected.Clopen
import Mathlib.Topology.Order.IntermediateValue
import Mathlib.Analysis.Convex.TotallyBounded
import Mathlib.Analysis.Convex.Topology
import Mathlib.Tactic

/-!
# Compactness of implemented payoff profiles

The action type has no topology or measurable-space instance. Compactness is a
consequence of regularity of the payoff profiles, not a restriction on action
labels. Moving diagonal anchors suffice on a compact connected type domain.
-/

open Set Filter Metric
open scoped Topology

namespace Envelope

section Oscillation

variable {T A : Type*} [TopologicalSpace T] [PreconnectedSpace T]

/-- Equicontinuity on a connected space bounds the variation between each fixed
pair of type points, uniformly over an arbitrary action index set. -/
theorem equicontinuous_pair_bound {F : A → T → ℝ} (hF : Equicontinuous F)
    (x y : T) : ∃ B : ℝ, ∀ a, dist (F a x) (F a y) ≤ B := by
  let P : T → T → Prop := fun x y => ∃ B : ℝ, ∀ a, dist (F a x) (F a y) ≤ B
  apply PreconnectedSpace.induction₂ P
  · intro x
    filter_upwards [(Metric.equicontinuousAt_iff_right.mp (hF x)) 1 zero_lt_one] with y hy
    exact ⟨1, fun a => (hy a).le⟩
  · refine ⟨?_⟩
    intro x y z hxy hyz
    obtain ⟨B, hB⟩ := hxy
    obtain ⟨C, hC⟩ := hyz
    exact ⟨B + C, fun a => (dist_triangle _ _ _).trans (add_le_add (hB a) (hC a))⟩
  · intro x y hxy
    obtain ⟨B, hB⟩ := hxy
    exact ⟨B, fun a => by simpa [dist_comm] using hB a⟩

/-- Compactness upgrades the pairwise bound to a common oscillation bound. -/
theorem equicontinuous_uniform_oscillation [CompactSpace T] [Nonempty T]
    {F : A → T → ℝ} (hF : Equicontinuous F) :
    ∃ K : ℝ, 0 ≤ K ∧ ∀ a x y, dist (F a x) (F a y) ≤ K := by
  classical
  let x₀ : T := Classical.choice inferInstance
  choose C hC using fun x : T => equicontinuous_pair_bound hF x x₀
  let U : T → Set T := fun x => {y | ∀ a, dist (F a x) (F a y) < 1}
  have hU : ∀ x, U x ∈ 𝓝 x := fun x =>
    (Metric.equicontinuousAt_iff_right.mp (hF x)) 1 zero_lt_one
  obtain ⟨s, _, hs⟩ := isCompact_univ.elim_nhds_subcover U (fun x _ => hU x)
  let B : ℝ := ∑ x ∈ s, (|C x| + 1)
  have hB : 0 ≤ B := Finset.sum_nonneg fun x _ => by positivity
  have hanchor : ∀ a y, dist (F a y) (F a x₀) ≤ B := by
    intro a y
    obtain ⟨x, hxs, hy⟩ := mem_iUnion₂.mp (hs (mem_univ y))
    have hlocal : dist (F a y) (F a x) ≤ 1 := by
      simpa [dist_comm] using (hy a).le
    calc
      dist (F a y) (F a x₀) ≤ dist (F a y) (F a x) + dist (F a x) (F a x₀) :=
        dist_triangle _ _ _
      _ ≤ 1 + C x := add_le_add hlocal (hC x a)
      _ ≤ |C x| + 1 := by linarith [le_abs_self (C x)]
      _ ≤ B := by
        exact Finset.single_le_sum (f := fun z => |C z| + 1)
          (fun z _ => by positivity) hxs
  refine ⟨B + B, add_nonneg hB hB, fun a x y => ?_⟩
  calc
    dist (F a x) (F a y) ≤ dist (F a x) (F a x₀) + dist (F a y) (F a x₀) :=
      dist_triangle_right _ _ _
    _ ≤ B + B := add_le_add (hanchor a x) (hanchor a y)

/-- A bounded implemented diagonal bounds all implemented profiles. No
measurability or continuity of the action-valued rule is assumed. -/
theorem implemented_uniform_bound [CompactSpace T] [Nonempty T]
    {F : A → T → ℝ} (hF : Equicontinuous F) (X : T → A)
    {M : ℝ} (hdiag : ∀ t, |F (X t) t| ≤ M) :
    ∃ B : ℝ, 0 ≤ B ∧ ∀ s t, |F (X s) t| ≤ B := by
  obtain ⟨K, hK, hosc⟩ := equicontinuous_uniform_oscillation hF
  refine ⟨|M| + K, add_nonneg (abs_nonneg M) hK, fun s t => ?_⟩
  have hdist := hosc (X s) t s
  rw [Real.dist_eq] at hdist
  calc
    |F (X s) t| = |(F (X s) t - F (X s) s) + F (X s) s| := by congr 1; ring
    _ ≤ |F (X s) t - F (X s) s| + |F (X s) s| := by
      simpa only [Real.norm_eq_abs] using norm_add_le (F (X s) t - F (X s) s) (F (X s) s)
    _ ≤ K + M := add_le_add hdist (hdiag s)
    _ ≤ |M| + K := by linarith [le_abs_self M]

end Oscillation

section Compactness

variable {T A : Type*} [TopologicalSpace T] [CompactSpace T]

/-- Payoff equivalence identifies actions with identical complete profiles. -/
def profileSetoid (F : A → C(T, ℝ)) : Setoid A := Setoid.ker F

/-- The profile map becomes injective only after payoff-equivalent labels
are identified. The nominal action map itself need not be injective. -/
def quotientProfileEmbedding (F : A → C(T, ℝ)) : Quotient (profileSetoid F) ↪ C(T, ℝ) where
  toFun := Quotient.lift F (fun _ _ h => h)
  inj' := by
    intro x y
    induction x using Quotient.inductionOn with
    | h a =>
      induction y using Quotient.inductionOn with
      | h b => exact fun h => Quotient.sound h

omit [CompactSpace T] in
@[simp] theorem quotientProfileEmbedding_mk (F : A → C(T, ℝ)) (a : A) :
    quotientProfileEmbedding F (Quotient.mk (profileSetoid F) a) = F a := rfl

/-- Arzelà–Ascoli in the continuous-map space, whose metric is the supremum
metric when the type domain is compact. -/
theorem profile_closure_compact {S : Set C(T, ℝ)}
    (hS : Equicontinuous (fun f : S => (f.val : T → ℝ)))
    {B : ℝ} (hB : ∀ f ∈ S, ∀ t, |f t| ≤ B) : IsCompact (closure S) := by
  let e := (ContinuousMap.isometryEquivBoundedOfCompact T ℝ).toHomeomorph
  have heq : Equicontinuous (fun f : e '' S => (f.val : T → ℝ)) := by
    intro x
    rw [Metric.equicontinuousAt_iff_right]
    intro ε hε
    filter_upwards [Metric.equicontinuousAt_iff_right.mp (hS x) ε hε] with y hy
    rintro ⟨g, f, hf, rfl⟩
    exact hy ⟨f, hf⟩
  have hc : IsCompact (closure (e '' S)) := by
    apply BoundedContinuousFunction.arzela_ascoli (Icc (-B) B) isCompact_Icc _ _ heq
    intro g t hg
    obtain ⟨f, hf, rfl⟩ := hg
    exact abs_le.mp (hB f hf t)
  rw [← e.image_closure] at hc
  exact e.isCompact_image.mp hc

/-- The implemented profile set retains only payoffs, without adding any
topology to the nominal action type. -/
def implementedProfiles (F : A → C(T, ℝ)) (X : T → A) : Set C(T, ℝ) :=
  range (fun s => F (X s))

omit [CompactSpace T] in
theorem implementedProfiles_equicontinuous (F : A → C(T, ℝ))
    (hF : Equicontinuous (fun a => (F a : T → ℝ))) (X : T → A) :
    Equicontinuous (fun f : implementedProfiles F X => (f.val : T → ℝ)) := by
  intro x
  rw [Metric.equicontinuousAt_iff_right]
  intro ε hε
  filter_upwards [Metric.equicontinuousAt_iff_right.mp (hF x) ε hε] with y hy
  rintro ⟨f, s, rfl⟩
  exact hy (X s)

/-- The substantive implemented-profile compactness result. Connectedness is
used to propagate the moving diagonal anchors over the whole type domain. -/
theorem implemented_profile_closure_compact [PreconnectedSpace T] [Nonempty T]
    (F : A → C(T, ℝ)) (hF : Equicontinuous (fun a => (F a : T → ℝ)))
    (X : T → A) {M : ℝ} (hdiag : ∀ t, |F (X t) t| ≤ M) :
    IsCompact (closure (implementedProfiles F X)) := by
  obtain ⟨B, _, hB⟩ := implemented_uniform_bound hF X hdiag
  apply profile_closure_compact (implementedProfiles_equicontinuous F hF X)
  rintro f ⟨s, rfl⟩ t
  exact hB s t

/-- Continuity of the diagonal, in particular absolute continuity, supplies
the boundedness hypothesis on a compact type domain. -/
theorem implemented_profile_closure_compact_of_continuous_diagonal
    [PreconnectedSpace T] [Nonempty T]
    (F : A → C(T, ℝ)) (hF : Equicontinuous (fun a => (F a : T → ℝ)))
    (X : T → A) (hv : Continuous (fun t => F (X t) t)) :
    IsCompact (closure (implementedProfiles F X)) := by
  let v : C(T, ℝ) := ⟨fun t => F (X t) t, hv⟩
  apply implemented_profile_closure_compact F hF X (M := ‖v‖)
  intro t
  exact (Real.norm_eq_abs _).symm ▸ v.norm_coe_le_norm t

/-- Precompactness and separability refer to payoff profiles in their
supremum metric, and do not give a measurable structure on action labels. -/
theorem implemented_profile_precompact
    [PreconnectedSpace T] [Nonempty T]
    (F : A → C(T, ℝ)) (hF : Equicontinuous (fun a => (F a : T → ℝ)))
    (X : T → A) (hv : Continuous (fun t => F (X t) t)) :
    TotallyBounded (implementedProfiles F X) ∧
      TopologicalSpace.IsSeparable (closure (implementedProfiles F X)) := by
  have hc := implemented_profile_closure_compact_of_continuous_diagonal F hF X hv
  exact ⟨hc.totallyBounded.subset subset_closure, hc.isSeparable⟩

end Compactness

section Convexification

variable {E : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E] [CompleteSpace E]

/-- In a real Banach space, the closed convex hull of a relatively compact
set is compact. This is a payoff-space statement, not a selection theorem. -/
theorem compact_closedConvexHull_of_compact_closure {S : Set E}
    (hS : IsCompact (closure S)) : IsCompact (closedConvexHull ℝ S) := by
  rw [closedConvexHull_eq_closure_convexHull]
  exact (totallyBounded_convexHull E (hS.totallyBounded.subset subset_closure)).closure
    |>.isCompact_of_isClosed isClosed_closure

end Convexification

/-- Combined compactness and convexity conclusion for the implemented payoff
profiles on a compact connected type domain. -/
theorem implemented_profile_convexification
    {T A : Type*} [TopologicalSpace T] [CompactSpace T]
    [PreconnectedSpace T] [Nonempty T]
    (F : A → C(T, ℝ)) (hF : Equicontinuous (fun a => (F a : T → ℝ)))
    (X : T → A) (hv : Continuous (fun t => F (X t) t)) :
    IsCompact (closedConvexHull ℝ (implementedProfiles F X)) ∧
      Convex ℝ (closedConvexHull ℝ (implementedProfiles F X)) := by
  exact ⟨compact_closedConvexHull_of_compact_closure
    (implemented_profile_closure_compact_of_continuous_diagonal F hF X hv),
    convex_closedConvexHull⟩

/-- The paper's unit-interval case is an instance of the general connected
compact-domain theorem. -/
theorem unitInterval_implemented_profile_compact
    {A : Type*} (F : A → C(Set.Icc (0 : ℝ) 1, ℝ))
    (hF : Equicontinuous (fun a => (F a : Set.Icc (0 : ℝ) 1 → ℝ)))
    (X : Set.Icc (0 : ℝ) 1 → A) (hv : Continuous (fun t => F (X t) t)) :
    IsCompact (closure (implementedProfiles F X)) ∧
      IsCompact (closedConvexHull ℝ (implementedProfiles F X)) ∧
      Convex ℝ (closedConvexHull ℝ (implementedProfiles F X)) := by
  letI : PreconnectedSpace (Set.Icc (0 : ℝ) 1) :=
    Subtype.preconnectedSpace isPreconnected_Icc
  letI : Nonempty (Set.Icc (0 : ℝ) 1) := ⟨⟨0, by constructor <;> norm_num⟩⟩
  exact ⟨implemented_profile_closure_compact_of_continuous_diagonal F hF X hv,
    implemented_profile_convexification F hF X hv⟩

/-- Uniformly equicontinuous nominal profiles can still be unbounded, even
when the implemented diagonal is identically zero. Compactness above applies
to implemented profiles, not to every action in the nominal action set. -/
theorem nominal_profiles_need_not_be_bounded
    {T : Type*} [TopologicalSpace T] [Nonempty T] :
    Equicontinuous (fun a : ℝ => fun _ : T => a) ∧
      (∀ t : T, (fun a : ℝ => fun _ : T => a) 0 t = 0) ∧
      ¬ ∃ B : ℝ, ∀ a : ℝ, ∀ t : T, |(fun a : ℝ => fun _ : T => a) a t| ≤ B := by
  refine ⟨?_, fun _ => rfl, ?_⟩
  · intro x
    rw [Metric.equicontinuousAt_iff_right]
    intro ε hε
    exact Filter.Eventually.of_forall fun _ _ => by simpa using hε
  · rintro ⟨B, hB⟩
    let t : T := Classical.choice inferInstance
    have h := hB (|B| + 1) t
    have hp : 0 ≤ |B| + 1 := by positivity
    simp only [abs_of_nonneg hp] at h
    linarith [le_abs_self B]

end Envelope
