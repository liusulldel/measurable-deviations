import Envelope.QuadraticNull
import Mathlib.Topology.Instances.Real.Lemmas

/-! The same obstruction with compact metric actions and continuous primitives. -/

open Set MeasureTheory

namespace Envelope.CompactCounterexample

abbrev TypeInterval := Icc (0 : ℝ) 1
abbrev Binary := ({0, 1} : Set ℝ)
abbrev Action := TypeInterval × Binary

instance : CompactSpace Binary := isCompact_iff_compactSpace.mp (Set.toFinite _).isCompact

theorem action_compact : CompactSpace Action := inferInstance

def payoff (x : Action) (t : ℝ) : ℝ := -(x.2 : ℝ) * (t - (x.1 : ℝ)) ^ 2

theorem payoff_jointly_continuous :
    Continuous (fun z : Action × ℝ => payoff z.1 z.2) := by
  unfold payoff
  fun_prop

noncomputable def chosen (A : Set ℝ) (s : TypeInterval) : Action :=
  (s, ⟨A.indicator (fun _ => (1 : ℝ)) s, by
    classical
    by_cases hs : (s : ℝ) ∈ A <;> simp [hs]⟩)

@[simp] theorem value_zero (A : Set ℝ) (s : TypeInterval) :
    payoff (chosen A s) s = 0 := by simp [payoff, chosen]

theorem payoff_nonpositive (x : Action) (t : ℝ) : payoff x t ≤ 0 := by
  have hc : (0 : ℝ) ≤ x.2 := by
    have hx := x.2.property
    simp only [mem_insert_iff, mem_singleton_iff] at hx
    rcases hx with hx | hx <;> simp [hx]
  exact mul_nonpos_of_nonpos_of_nonneg (neg_nonpos.mpr hc) (sq_nonneg _)

theorem chosen_optimal (A : Set ℝ) (s : TypeInterval) (x : Action) :
    payoff x s ≤ payoff (chosen A s) s := by
  simpa using payoff_nonpositive x s

/-- A constant good selector is available in the same economy. -/
def goodAction : Action := (⟨0, by norm_num⟩, ⟨0, by simp⟩)

@[simp] theorem goodAction_payoff (s : ℝ) : payoff goodAction s = 0 := by
  simp [payoff, goodAction]

theorem goodAction_optimal (s : ℝ) (x : Action) :
    payoff x s ≤ payoff goodAction s := by simpa using payoff_nonpositive x s

theorem payoff_chosen_eq (A : Set ℝ) (s : TypeInterval) (t : ℝ) :
    payoff (chosen A s) t = QuadraticNull.payoff A (QuadraticNull.diagonal s) t := rfl

/-- A total ambient extension represents the compact selector on the unit interval.
It is used only to express interval integrability with real variables. -/
noncomputable def extendedPayoff (A : Set ℝ) (u t : ℝ) : ℝ :=
  -(A.indicator (fun _ => (1 : ℝ)) u) * (t - u) ^ 2

@[simp] theorem extendedPayoff_on_interval (A : Set ℝ) (u : TypeInterval) (t : ℝ) :
    extendedPayoff A u t = payoff (chosen A u) t := rfl

theorem compact_selector_bad_deviations (A : Set ℝ)
    (hA : A ⊆ Icc (1 / 3 : ℝ) (2 / 3 : ℝ))
    (hAn : ¬ NullMeasurableSet A volume) (h : ℝ)
    (hh : |h| < 1 / 12) (hh0 : h ≠ 0) :
    ¬ Integrable (fun s => extendedPayoff A (s + h) s)
      (volume.restrict (Icc (1 / 4 : ℝ) (3 / 4 : ℝ))) :=
  QuadraticNull.shifted_payoff_not_integrable A hA hAn h hh hh0

/-- An unconditional witness, with classical existence discharged in QuadraticNull. -/
theorem exists_compact_selector_bad_deviations :
    ∃ A : Set ℝ, A ⊆ Icc (1 / 3 : ℝ) (2 / 3 : ℝ) ∧
      (∀ s : TypeInterval, ∀ x : Action, payoff x s ≤ payoff (chosen A s) s) ∧
      (∀ h : ℝ, |h| < 1 / 12 → h ≠ 0 →
        ¬ Integrable (fun s => extendedPayoff A (s + h) s)
          (volume.restrict (Icc (1 / 4 : ℝ) (3 / 4 : ℝ)))) := by
  obtain ⟨A, hA, hAn⟩ := QuadraticNull.exists_nonmeasurable_interior
  exact ⟨A, hA, chosen_optimal A, fun h hh hh0 =>
    compact_selector_bad_deviations A hA hAn h hh hh0⟩

end Envelope.CompactCounterexample
