import Envelope.UniformQuotients

/-! One witness satisfies every substantive part of the paper's main
counterexample simultaneously, including the genuine uniform-integrability
hypothesis on fixed-action quotient suprema. -/

open Set MeasureTheory

namespace Envelope.QuadraticNull

theorem complete_counterexample :
    ∃ A : Set ℝ,
      A ⊆ Icc (1 / 3 : ℝ) (2 / 3 : ℝ) ∧
      (∀ x t, DifferentiableAt ℝ (payoff A x) t) ∧
      (∀ x, x.1 ∈ Icc (0 : ℝ) 1 → LipschitzOnWith 2 (payoff A x) (Icc (0 : ℝ) 1)) ∧
      (∀ t x, payoff A x t ≤ payoff A (diagonal t) t) ∧
      (∀ t, payoff A (diagonal t) t = 0) ∧
      (∀ t, HasDerivAt (payoff A (diagonal t)) 0 t) ∧
      AbsolutelyContinuousOnInterval (fun t => payoff A (diagonal t) t) 0 1 ∧
      (∀ a b, payoff A (diagonal b) b = payoff A (diagonal a) a +
        ∫ s in a..b, deriv (payoff A (diagonal s)) s) ∧
      (∀ h, Measurable (actualQuotientSup A h)) ∧
      UniformIntegrable (actualQuotientSup A) 1 (volume.restrict (Icc (0 : ℝ) 1)) ∧
      (∀ m, |m| < 1 / 12 → m ≠ 0 →
        ¬ Integrable (fun s => payoff A (diagonal (s + m)) s)
          (volume.restrict (Icc (1 / 4 : ℝ) (3 / 4 : ℝ)))) := by
  obtain ⟨A, hA, hm, hUI, hbad⟩ :=
    exists_uniformIntegrable_suprema_with_nonintegrable_shifts
  exact ⟨A, hA, fun x t => (hasDerivAt_payoff A x t).differentiableAt,
    payoff_lipschitzOnWith A, diagonal_optimal A, payoff_diagonal A,
    derivative_on_diagonal A, value_absolutelyContinuous A, envelope_formula A,
    hm, hUI, hbad⟩

end Envelope.QuadraticNull
