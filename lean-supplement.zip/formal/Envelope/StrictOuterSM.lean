import Mathlib

/-!
# The literal strict outer Spence–Mirrlees condition

The universal quantifiers in published Definition 7 include constant allocation
and payment rules. Their shifted integrals exist under the stated type
continuity, but the upper derivative is identically zero. It cannot satisfy
footnote 17's strict single-crossing implication on a nondegenerate interval.

The limsup is the actual two-sided upper derivative, not an assumed derivative
or an arithmetic surrogate. Integrability of the witness is proved explicitly.
The integral and real limsup are totalized in Lean. No equivalence with the
published definition is asserted for other paths whose integrals are undefined
or whose upper derivatives are infinite; only the finite, integrable constant
witness is needed for the obstruction.
-/

open Set Filter MeasureTheory
open scoped Topology

namespace Envelope.StrictOuterSM

def StrictSingleCrossingOn (S : Set ℝ) (q : ℝ → ℝ) : Prop :=
  ∀ ⦃n⦄, n ∈ S → ∀ ⦃n'⦄, n' ∈ S → n < n' → 0 ≤ q n → 0 < q n'

theorem StrictSingleCrossingOn.mono {S T : Set ℝ} {q : ℝ → ℝ}
    (h : StrictSingleCrossingOn S q) (hTS : T ⊆ S) :
    StrictSingleCrossingOn T q := by
  intro n hn n' hn' hlt hnonneg
  exact h (hTS hn) (hTS hn') hlt hnonneg

noncomputable def upperDerivative (J : ℝ → ℝ) : ℝ :=
  Filter.limsup (fun h : ℝ => (J h - J 0) / h) (𝓝[≠] (0 : ℝ))

theorem upperDerivative_const (c : ℝ) :
    upperDerivative (fun _ => c) = 0 := by
  simp [upperDerivative]

theorem zero_not_strictSingleCrossingOn
    (S : Set ℝ) (n n' : ℝ) (hn : n ∈ S) (hn' : n' ∈ S) (hlt : n < n') :
    ¬ StrictSingleCrossingOn S (fun _ => 0) := by
  intro h
  exact (lt_irrefl (0 : ℝ)) (h hn hn' hlt le_rfl)

def displacementWindow : Set ℝ := Ioo (-1 / 8 : ℝ) (1 / 8)

theorem displacementWindow_nontrivial :
    (-1 / 16 : ℝ) ∈ displacementWindow ∧
    (1 / 16 : ℝ) ∈ displacementWindow ∧ (-1 / 16 : ℝ) < 1 / 16 := by
  norm_num [displacementWindow]

theorem shift_admissible {s h : ℝ}
    (hs : s ∈ Icc (1 / 4 : ℝ) (3 / 4)) (hh : h ∈ displacementWindow) :
    s + h ∈ Icc (0 : ℝ) 1 := by
  rcases hs with ⟨hs₀, hs₁⟩
  rcases hh with ⟨hh₀, hh₁⟩
  constructor <;> linarith

noncomputable def shiftedIntegral {A : Type*}
    (f : A → ℝ → ℝ → ℝ) (Y : ℝ → A) (P : ℝ → ℝ)
    (r t n h : ℝ) : ℝ :=
  ∫ s in r..t, f (Y (s + h)) (P (s + h)) (s + n)

theorem constantMechanism_integrable {A : Type*}
    (f : A → ℝ → ℝ → ℝ) (y : A) (p : ℝ)
    (hf : ContinuousOn (f y p) (Icc (0 : ℝ) 1))
    {n : ℝ} (hn : n ∈ displacementWindow) (h : ℝ) :
    IntervalIntegrable
      (fun s => f ((fun _ => y) (s + h)) ((fun _ => p) (s + h)) (s + n))
      volume (1 / 4) (3 / 4) := by
  apply ContinuousOn.intervalIntegrable_of_Icc (by norm_num : (1 / 4 : ℝ) ≤ 3 / 4)
  exact hf.comp (continuous_id.add_const n).continuousOn
    (fun s hs => shift_admissible hs hn)

theorem constantMechanism_upperDerivative {A : Type*}
    (f : A → ℝ → ℝ → ℝ) (y : A) (p r t n : ℝ) :
    upperDerivative (shiftedIntegral f (fun _ => y) (fun _ => p) r t n) = 0 := by
  exact upperDerivative_const _

/-- A necessary restriction of the original strict condition to the single
interior integration window [1/4,3/4] and small type displacements. A condition
quantifying over all interior windows implies this restriction. -/
def StrictOuterConditionAtWindow {A : Type*} [Preorder A]
    (f : A → ℝ → ℝ → ℝ) : Prop :=
  ∀ (Y : ℝ → A) (P : ℝ → ℝ), MonotoneOn Y (Icc (0 : ℝ) 1) →
    StrictSingleCrossingOn displacementWindow
      (fun n => upperDerivative (shiftedIntegral f Y P (1 / 4) (3 / 4) n))

/-- A totalized encoding of the universal strict test using real extensions
of rules on [0,1]. The type displacement interval keeps every integrated type
inside [0,1]. Its restriction to the integrable constant witness agrees with
the ordinary-integral test and already suffices for the contradiction. -/
def LiteralStrictOuterCondition {A : Type*} [Preorder A]
    (f : A → ℝ → ℝ → ℝ) : Prop :=
  ∀ (Y : ℝ → A) (P : ℝ → ℝ), MonotoneOn Y (Icc (0 : ℝ) 1) →
    ∀ r ∈ Ioo (0 : ℝ) 1, ∀ t ∈ Ioo (0 : ℝ) 1, r < t →
      StrictSingleCrossingOn (Ioo (-r) (1 - t))
        (fun n => upperDerivative (shiftedIntegral f Y P r t n))

theorem literalStrictOuterCondition_implies_window {A : Type*} [Preorder A]
    {f : A → ℝ → ℝ → ℝ} (h : LiteralStrictOuterCondition f) :
    StrictOuterConditionAtWindow f := by
  intro Y P hY
  apply (h Y P hY (1 / 4) (by norm_num) (3 / 4) (by norm_num)
    (by norm_num)).mono
  intro n hn
  rcases hn with ⟨hn₀, hn₁⟩
  constructor <;> linarith

/-- All displacements tested here remain within the paper's type interval. -/
theorem constant_mechanism_counterexample {A : Type*} [Preorder A]
    (f : A → ℝ → ℝ → ℝ) (y : A) (p : ℝ)
    (hf : ContinuousOn (f y p) (Icc (0 : ℝ) 1)) :
    MonotoneOn (fun _ : ℝ => y) (Icc (0 : ℝ) 1) ∧
    (∀ n ∈ displacementWindow, ∀ h ∈ displacementWindow,
      IntervalIntegrable
        (fun s => f ((fun _ => y) (s + h)) ((fun _ => p) (s + h)) (s + n))
        volume (1 / 4) (3 / 4)) ∧
    (∀ n : ℝ, upperDerivative
      (shiftedIntegral f (fun _ => y) (fun _ => p) (1 / 4) (3 / 4) n) = 0) ∧
    ¬ StrictSingleCrossingOn displacementWindow
      (fun n => upperDerivative
        (shiftedIntegral f (fun _ => y) (fun _ => p) (1 / 4) (3 / 4) n)) := by
  refine ⟨fun _ _ _ _ _ => le_rfl, ?_, ?_, ?_⟩
  · intro n hn h _
    exact constantMechanism_integrable f y p hf hn h
  · exact fun n => constantMechanism_upperDerivative f y p _ _ n
  · simp_rw [constantMechanism_upperDerivative]
    obtain ⟨hn, hn', hlt⟩ := displacementWindow_nontrivial
    exact zero_not_strictSingleCrossingOn _ _ _ hn hn' hlt

theorem no_strictOuterConditionAtWindow {A : Type*} [Preorder A]
    (f : A → ℝ → ℝ → ℝ) (y : A) (p : ℝ)
    (hf : ContinuousOn (f y p) (Icc (0 : ℝ) 1)) :
    ¬ StrictOuterConditionAtWindow f := by
  obtain ⟨hmono, _, _, hnot⟩ := constant_mechanism_counterexample f y p hf
  intro h
  exact hnot (h (fun _ => y) (fun _ => p) hmono)

/-- No nonempty payoff environment with continuous fixed-outcome/payment type
profiles satisfies the literal strict condition. The witness integrals have
been proved integrable in `constant_mechanism_counterexample`; no default value
of a nonintegrable Lean integral is used to support the economic objection. -/
theorem literal_strict_condition_impossible {A : Type*} [Preorder A] [Nonempty A]
    (f : A → ℝ → ℝ → ℝ)
    (hf : ∀ y p, ContinuousOn (f y p) (Icc (0 : ℝ) 1)) :
    ¬ LiteralStrictOuterCondition f := by
  let y : A := Classical.choice (inferInstance : Nonempty A)
  intro h
  exact no_strictOuterConditionAtWindow f y 0 (hf y 0)
    (literalStrictOuterCondition_implies_window h)

/-- An even weaker necessary test: require strict crossing only on paths whose
integrals exist throughout the tested window and whose shifted integrals have
ordinary finite derivatives at zero. The constant-path obstruction survives
this explicit ordinary-integration restriction. -/
def OrdinaryStrictOuterConditionAtWindow {A : Type*} [Preorder A]
    (f : A → ℝ → ℝ → ℝ) : Prop :=
  ∀ (Y : ℝ → A) (P : ℝ → ℝ), MonotoneOn Y (Icc (0 : ℝ) 1) →
    (∀ n ∈ displacementWindow, ∀ h ∈ displacementWindow,
      IntervalIntegrable (fun s => f (Y (s + h)) (P (s + h)) (s + n))
        volume (1 / 4) (3 / 4)) →
    (∀ n ∈ displacementWindow, ∃ d : ℝ,
      HasDerivAt (shiftedIntegral f Y P (1 / 4) (3 / 4) n) d 0) →
    StrictSingleCrossingOn displacementWindow
      (fun n => upperDerivative (shiftedIntegral f Y P (1 / 4) (3 / 4) n))

theorem ordinary_strict_condition_impossible {A : Type*} [Preorder A] [Nonempty A]
    (f : A → ℝ → ℝ → ℝ)
    (hf : ∀ y p, ContinuousOn (f y p) (Icc (0 : ℝ) 1)) :
    ¬ OrdinaryStrictOuterConditionAtWindow f := by
  let y : A := Classical.choice (inferInstance : Nonempty A)
  obtain ⟨hmono, hint, _, hnot⟩ := constant_mechanism_counterexample f y 0 (hf y 0)
  intro h
  apply hnot (h (fun _ => y) (fun _ => 0) hmono hint ?_)
  intro n _
  exact ⟨0, hasDerivAt_const 0 _⟩

end Envelope.StrictOuterSM
