import Envelope.InformationMixtures
import Mathlib.Topology.EMetricSpace.Lipschitz

/-! Independent binary-information repairs: uniform convex-test convergence and
joint continuity of expected payoffs with a common type-Lipschitz bound. -/

open Set MeasureTheory Filter TopologicalSpace
open scoped Topology ENNReal NNReal
noncomputable section
namespace Envelope.InformationCounterexample

local instance : TopologicalSpace Law := strictRayTopology

/-- The test class in the supplement's weaker, recoverable Corollary S.1. -/
def NormalizedConvexTest (v : ℝ → ℝ) : Prop :=
  ContinuousOn v (Icc 0 1) ∧ ConvexOn ℝ (Icc 0 1) v ∧
    ∀ x ∈ Icc (0:ℝ) 1, |v x| ≤ 1

lemma normalized_expectation_bounds (z : Law) {v : ℝ → ℝ}
    (hv : NormalizedConvexTest v) :
    -1 ≤ (∫ x : Posterior, v x ∂z.measure) ∧ (∫ x : Posterior, v x ∂z.measure) ≤ 1 := by
  constructor
  · have h := integral_mono (μ:=z.measure) (integrable_const (-1:ℝ)) (integral_continuous _ hv.1)
      (fun x : Posterior => (abs_le.mp (hv.2.2 x x.property)).1)
    simpa using h
  · have h := integral_mono (μ:=z.measure) (integral_continuous _ hv.1) (integrable_const (1:ℝ))
      (fun x : Posterior => (abs_le.mp (hv.2.2 x x.property)).2)
    simpa using h

lemma normalized_expectation_difference_bound (z w : Law) {v : ℝ → ℝ}
    (hv : NormalizedConvexTest v) :
    |(∫ x : Posterior, v x ∂z.measure)-(∫ x : Posterior, v x ∂w.measure)| ≤ 2 := by
  have hz := normalized_expectation_bounds z hv
  have hw := normalized_expectation_bounds w hv
  rw [abs_le]
  constructor <;> linarith

lemma zero_normalized_convex : NormalizedConvexTest (fun _ : ℝ => 0) := by
  refine ⟨continuousOn_const, convexOn_const (0:ℝ) (convex_Icc _ _), ?_⟩
  intro x hx
  norm_num

def convexDiscrepancy (z w : Law) : ℝ :=
  sSup {r : ℝ | ∃ v : ℝ → ℝ, NormalizedConvexTest v ∧
    r=|(∫ x : Posterior, v x ∂z.measure)-(∫ x : Posterior, v x ∂w.measure)|}

lemma convexDiscrepancy_nonneg (z w : Law) : 0 ≤ convexDiscrepancy z w := by
  apply le_csSup
  · refine ⟨2, ?_⟩
    rintro r ⟨v, hv, rfl⟩
    exact normalized_expectation_difference_bound z w hv
  · exact ⟨fun _ => 0, zero_normalized_convex, by simp⟩

lemma convexDiscrepancy_le {z w : Law} {c : ℝ}
    (h : ∀ v, NormalizedConvexTest v →
      |(∫ x : Posterior, v x ∂z.measure)-(∫ x : Posterior, v x ∂w.measure)| ≤ c) :
    convexDiscrepancy z w ≤ c := by
  apply csSup_le
  · exact ⟨0, fun _ => 0, zero_normalized_convex, by simp⟩
  · rintro r ⟨v, hv, rfl⟩
    exact h v hv

/-- One ambient neighborhood controls every normalized convex test simultaneously. -/
lemma uniform_convex_eventually_bound (z : Law) (α : ℝ)
    (hα : α ∈ Icc (0:ℝ) 1) (hpos : 0 < α) :
    ∀ᶠ w in 𝓝 z, ∀ v, NormalizedConvexTest v →
      |(∫ x : Posterior, v x ∂w.measure)-(∫ x : Posterior, v x ∂z.measure)| ≤ 2*α := by
  have hlo : ∀ᶠ w in 𝓝 z, ∀ v, NormalizedConvexTest v →
      (∫ x : Posterior, v x ∂z.measure)-(∫ x : Posterior, v x ∂w.measure) ≤ 2*α := by
    by_cases hz : Blackwell z baseLaw
    · apply Eventually.of_forall
      intro w v hv
      have hzv := hz v hv.1 hv.2.1
      have hwv := base_le w v hv.1 hv.2.1
      linarith
    · have hopen : IsOpen {w : Law | StrictBlackwell (mixLaw α hα z baseLaw) w} :=
        TopologicalSpace.isOpen_generateFrom_of_mem (Or.inr ⟨mixLaw α hα z baseLaw, rfl⟩)
      filter_upwards [hopen.mem_nhds (strict_mix_base α hα z hpos hz)] with w hw
      intro v hv
      have hm := hw.1 v hv.1 hv.2.1
      rw [integral_mixLaw _ _ _ _ hv.1] at hm
      have hzb := normalized_expectation_bounds z hv
      have hbb := normalized_expectation_bounds baseLaw hv
      have hb := mul_le_mul_of_nonneg_left
        (show (∫ x : Posterior, v x ∂z.measure)-(∫ x : Posterior, v x ∂baseLaw.measure) ≤ 2 by linarith) hα.1
      nlinarith
  have hhi : ∀ᶠ w in 𝓝 z, ∀ v, NormalizedConvexTest v →
      (∫ x : Posterior, v x ∂w.measure)-(∫ x : Posterior, v x ∂z.measure) ≤ 2*α := by
    by_cases hz : Blackwell fullLaw z
    · apply Eventually.of_forall
      intro w v hv
      have hzv := hz v hv.1 hv.2.1
      have hwv := le_full w v hv.1 hv.2.1
      linarith
    · have hopen : IsOpen {w : Law | StrictBlackwell w (mixLaw α hα z fullLaw)} :=
        TopologicalSpace.isOpen_generateFrom_of_mem (Or.inl ⟨mixLaw α hα z fullLaw, rfl⟩)
      filter_upwards [hopen.mem_nhds (strict_mix_full α hα z hpos hz)] with w hw
      intro v hv
      have hm := hw.1 v hv.1 hv.2.1
      rw [integral_mixLaw _ _ _ _ hv.1] at hm
      have hzb := normalized_expectation_bounds z hv
      have hfb := normalized_expectation_bounds fullLaw hv
      have hb := mul_le_mul_of_nonneg_left
        (show (∫ x : Posterior, v x ∂fullLaw.measure)-(∫ x : Posterior, v x ∂z.measure) ≤ 2 by linarith) hα.1
      nlinarith
  filter_upwards [hlo, hhi] with w hwlo hwhi
  intro v hv
  rw [abs_le]
  constructor <;> linarith [hwlo v hv, hwhi v hv]

/-- The repaired Corollary S.1, for arbitrary nets in the ambient topology. -/
theorem convexDiscrepancy_tendsto {ι : Type*} {l : Filter ι} {u : ι → Law} {z : Law}
    (hu : Tendsto u l (𝓝 z)) :
    Tendsto (fun i => convexDiscrepancy (u i) z) l (𝓝 (0:ℝ)) := by
  apply Metric.tendsto_nhds.2
  intro ε hε
  obtain ⟨n, hn⟩ := ((tendsto_order.1 radius_tendsto).2 (ε/2) (by linarith)).exists
  have hr : radius n ∈ Icc (0:ℝ) 1 :=
    ⟨(radius_pos n).le, (radius_mem n).2.trans (by norm_num)⟩
  filter_upwards [hu.eventually (uniform_convex_eventually_bound z _ hr (radius_pos n))]
    with i hi
  have hb := convexDiscrepancy_le hi
  have hnz := convexDiscrepancy_nonneg (u i) z
  rw [Real.dist_eq, sub_zero, abs_of_nonneg hnz]
  linarith

lemma normalized_expectation_continuous {v : ℝ → ℝ} (hv : NormalizedConvexTest v) :
    Continuous (fun z : Law => ∫ x : Posterior, v x ∂z.measure) := by
  apply continuous_iff_continuousAt.2
  intro z
  apply Metric.tendsto_nhds.2
  intro ε hε
  obtain ⟨n, hn⟩ := ((tendsto_order.1 radius_tendsto).2 (ε/2) (by linarith)).exists
  have hr : radius n ∈ Icc (0:ℝ) 1 :=
    ⟨(radius_pos n).le, (radius_mem n).2.trans (by norm_num)⟩
  filter_upwards [uniform_convex_eventually_bound z _ hr (radius_pos n)] with w hw
  rw [Real.dist_eq]
  exact lt_of_le_of_lt (hw v hv) (by linarith)

/-- Every fixed continuous convex payoff has continuous expectation in the full
ambient strict-ray topology, not merely along the displayed counterexample chain. -/
theorem convex_expectation_continuous {v : ℝ → ℝ}
    (hv : ContinuousOn v (Icc 0 1)) (hc : ConvexOn ℝ (Icc 0 1) v) :
    Continuous (fun z : Law => ∫ x : Posterior, v x ∂z.measure) := by
  obtain ⟨C, hC⟩ := isCompact_Icc.exists_bound_of_continuousOn hv
  let M := |C|+1
  have hM : 0 < M := by dsimp [M]; positivity
  let g : ℝ → ℝ := fun x => (1/M)*v x
  have hg : NormalizedConvexTest g := by
    refine ⟨continuousOn_const.mul hv, ?_, ?_⟩
    · simpa only [smul_eq_mul] using hc.smul (show 0 ≤ 1/M by positivity)
    · intro x hx
      have hb : |v x| ≤ M := by
        have hxC := hC x hx
        rw [Real.norm_eq_abs] at hxC
        exact hxC.trans ((le_abs_self C).trans (by dsimp [M]; linarith))
      dsimp [g]
      rw [abs_mul, abs_of_pos (by positivity : 0 < 1/M)]
      calc
        (1/M)*|v x| ≤ (1/M)*M := mul_le_mul_of_nonneg_left hb (by positivity)
        _ = 1 := one_div_mul_cancel hM.ne'
  have ht := (continuous_const : Continuous (fun _ : Law => M)).mul
    (normalized_expectation_continuous hg)
  have he : (fun z : Law => M*(∫ x : Posterior, g x ∂z.measure)) =
      (fun z : Law => ∫ x : Posterior, v x ∂z.measure) := by
    funext z
    dsimp [g]
    rw [integral_const_mul]
    field_simp
  rw [← he]
  exact ht

/-- A common Lipschitz bound in type passes to expectations under every probability law. -/
lemma expectation_type_lipschitz (V : Posterior → ℝ → ℝ) (K : ℝ≥0)
    (hv : ∀ t, ContinuousOn (V t) (Icc 0 1))
    (hK : ∀ x ∈ Icc (0:ℝ) 1, LipschitzWith K (fun t : Posterior => V t x)) (z : Law) :
    LipschitzWith K (fun t : Posterior => ∫ x : Posterior, V t x ∂z.measure) := by
  apply LipschitzWith.of_dist_le_mul
  intro s t
  have hb : ∀ᵐ x : Posterior ∂z.measure, ‖V s x-V t x‖ ≤ (K:ℝ)*dist s t :=
    Eventually.of_forall fun x => by
      simpa only [dist_eq_norm] using (hK x x.property).dist_le_mul s t
  have hh := norm_integral_le_of_norm_le_const hb
  rw [integral_sub (integral_continuous _ (hv s)) (integral_continuous _ (hv t))] at hh
  simpa only [dist_eq_norm, probReal_univ, mul_one] using hh

/-- Binary-state counterpart of the supplement's repaired joint-continuity conclusion.
The law coordinate uses the full ambient strict-ray topology. -/
theorem expected_payoff_jointly_continuous (V : Posterior → ℝ → ℝ) (K : ℝ≥0)
    (hv : ∀ t, ContinuousOn (V t) (Icc 0 1))
    (hc : ∀ t, ConvexOn ℝ (Icc 0 1) (V t))
    (hK : ∀ x ∈ Icc (0:ℝ) 1, LipschitzWith K (fun t : Posterior => V t x)) :
    Continuous (fun p : Law × Posterior => ∫ x : Posterior, V p.2 x ∂p.1.measure) := by
  exact continuous_prod_of_continuous_lipschitzWith' _ K
    (expectation_type_lipschitz V K hv hK)
    (fun t => convex_expectation_continuous (hv t) (hc t))

/-- Continuous monetary aggregation preserves the repaired joint-continuity result. -/
theorem information_utility_jointly_continuous (V : Posterior → ℝ → ℝ) (K : ℝ≥0)
    (hv : ∀ t, ContinuousOn (V t) (Icc 0 1))
    (hc : ∀ t, ConvexOn ℝ (Icc 0 1) (V t))
    (hK : ∀ x ∈ Icc (0:ℝ) 1, LipschitzWith K (fun t : Posterior => V t x))
    (g : ℝ × ℝ → ℝ) (hg : Continuous g) :
    Continuous (fun p : (Law × Posterior) × ℝ =>
      g ((∫ x : Posterior, V p.1.2 x ∂p.1.1.measure), p.2)) := by
  exact hg.comp (((expected_payoff_jointly_continuous V K hv hc hK).comp continuous_fst).prodMk
    continuous_snd)

end Envelope.InformationCounterexample
