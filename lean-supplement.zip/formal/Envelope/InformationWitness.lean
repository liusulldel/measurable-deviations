import Mathlib.Analysis.Normed.Module.Convex
import Mathlib.MeasureTheory.Integral.Bochner.Basic
import Mathlib.Tactic

/-! Explicit continuous difference-of-convex tests and posterior probability laws. -/

open Set MeasureTheory
open scoped ENNReal

noncomputable section

namespace Envelope.InformationCounterexample

abbrev Posterior := Icc (0 : ℝ) 1

def center : Posterior := ⟨1 / 2, by norm_num⟩

def left (ε : ℝ) (hε : ε ∈ Icc (0 : ℝ) (1 / 2)) : Posterior :=
  ⟨1 / 2 - ε, by constructor <;> linarith [hε.1, hε.2]⟩

def right (ε : ℝ) (hε : ε ∈ Icc (0 : ℝ) (1 / 2)) : Posterior :=
  ⟨1 / 2 + ε, by constructor <;> linarith [hε.1, hε.2]⟩

noncomputable def uninformative : Measure Posterior := Measure.dirac center

noncomputable def spread (ε : ℝ) (hε : ε ∈ Icc (0 : ℝ) (1 / 2)) :
    Measure Posterior :=
  (1 / 2 : ℝ≥0∞) • Measure.dirac (left ε hε) +
    (1 / 2 : ℝ≥0∞) • Measure.dirac (right ε hε)

noncomputable def dcPositive (ε x : ℝ) : ℝ :=
  (|x - (1 / 2 - ε)| + |x - (1 / 2 + ε)|) / ε

noncomputable def dcNegative (ε x : ℝ) : ℝ := 2 * |x - 1 / 2| / ε + 1

noncomputable def realTest (ε x : ℝ) : ℝ := dcPositive ε x - dcNegative ε x

noncomputable def test (ε : ℝ) (x : Posterior) : ℝ := realTest ε x

theorem integral_uninformative (v : Posterior → ℝ) :
    ∫ x, v x ∂uninformative = v center := by simp [uninformative]

theorem integrable_uninformative (v : Posterior → ℝ) :
    Integrable v uninformative := integrable_dirac (by simp)

theorem integrable_spread (ε : ℝ) (hε : ε ∈ Icc (0 : ℝ) (1 / 2))
    (v : Posterior → ℝ) : Integrable v (spread ε hε) := by
  unfold spread
  apply integrable_add_measure.mpr
  constructor <;> apply Integrable.smul_measure (integrable_dirac (by simp)) <;> norm_num

theorem integral_spread (ε : ℝ) (hε : ε ∈ Icc (0 : ℝ) (1 / 2))
    (v : Posterior → ℝ) :
    ∫ x, v x ∂spread ε hε = (v (left ε hε) + v (right ε hε)) / 2 := by
  unfold spread
  rw [integral_add_measure
    ((integrable_dirac (by simp)).smul_measure (by norm_num))
    ((integrable_dirac (by simp)).smul_measure (by norm_num))]
  simp [integral_smul_measure, integral_dirac]
  ring

instance uninformative_probability : IsProbabilityMeasure uninformative := by
  unfold uninformative
  infer_instance

instance spread_probability (ε : ℝ) (hε : ε ∈ Icc (0 : ℝ) (1 / 2)) :
    IsProbabilityMeasure (spread ε hε) := by
  constructor
  norm_num [spread, Measure.add_apply, Measure.smul_apply]
  exact ENNReal.inv_two_add_inv_two

theorem mean_uninformative : ∫ x, (x : ℝ) ∂uninformative = 1 / 2 := by
  rw [integral_uninformative]
  rfl

theorem mean_spread (ε : ℝ) (hε : ε ∈ Icc (0 : ℝ) (1 / 2)) :
    ∫ x, (x : ℝ) ∂spread ε hε = 1 / 2 := by
  rw [integral_spread]
  simp only [left, right]
  ring

theorem convex_abs_sub (c : ℝ) :
    ConvexOn ℝ univ (fun x : ℝ => |x - c|) := by
  simpa [Real.dist_eq] using convexOn_univ_dist c

theorem dcPositive_convex (ε : ℝ) (hε : 0 < ε) :
    ConvexOn ℝ univ (dcPositive ε) := by
  have h := ((convex_abs_sub (1 / 2 - ε)).add
    (convex_abs_sub (1 / 2 + ε))).smul (inv_nonneg.mpr hε.le)
  convert h using 1
  funext x
  simp only [dcPositive, Pi.add_apply, smul_eq_mul]
  ring

theorem dcNegative_convex (ε : ℝ) (hε : 0 < ε) :
    ConvexOn ℝ univ (dcNegative ε) := by
  have h := ((convex_abs_sub (1 / 2)).smul
    (show 0 ≤ 2 / ε by positivity)).add_const 1
  convert h using 1
  funext x
  simp only [dcNegative, Pi.add_apply, smul_eq_mul]
  ring

theorem dcPositive_continuous (ε : ℝ) : Continuous (dcPositive ε) := by
  unfold dcPositive
  fun_prop

theorem dcNegative_continuous (ε : ℝ) : Continuous (dcNegative ε) := by
  unfold dcNegative
  fun_prop

theorem realTest_continuous (ε : ℝ) : Continuous (realTest ε) :=
  (dcPositive_continuous ε).sub (dcNegative_continuous ε)

theorem test_continuous (ε : ℝ) : Continuous (test ε) :=
  (realTest_continuous ε).comp continuous_subtype_val

theorem realTest_abs_le_one (ε : ℝ) (hε : 0 < ε) (x : ℝ) :
    |realTest ε x| ≤ 1 := by
  have hlo := abs_add_le (x - (1 / 2 - ε)) (x - (1 / 2 + ε))
  have heq : x - (1 / 2 - ε) + (x - (1 / 2 + ε)) = 2 * (x - 1 / 2) := by ring
  rw [heq, abs_mul] at hlo
  norm_num at hlo
  have ha := abs_add_le (x - 1 / 2) ε
  have hb := abs_add_le (x - 1 / 2) (-ε)
  rw [abs_of_pos hε] at ha
  rw [abs_neg, abs_of_pos hε] at hb
  have hea : x - 1 / 2 + ε = x - (1 / 2 - ε) := by ring
  have heb : x - 1 / 2 + -ε = x - (1 / 2 + ε) := by ring
  rw [hea] at ha
  rw [heb] at hb
  have hr : realTest ε x =
      (|x - (1 / 2 - ε)| + |x - (1 / 2 + ε)| - 2 * |x - 1 / 2|) / ε - 1 := by
    unfold realTest dcPositive dcNegative
    ring
  rw [hr, abs_le]
  constructor
  · have := div_nonneg (show 0 ≤ |x - (1 / 2 - ε)| + |x - (1 / 2 + ε)| -
        2 * |x - 1 / 2| by linarith) hε.le
    linarith
  · have : (|x - (1 / 2 - ε)| + |x - (1 / 2 + ε)| - 2 * |x - 1 / 2|) / ε ≤ 2 :=
      (div_le_iff₀ hε).mpr (by linarith)
    linarith

theorem test_abs_le_one (ε : ℝ) (hε : 0 < ε) (x : Posterior) :
    |test ε x| ≤ 1 := realTest_abs_le_one ε hε x

theorem realTest_center (ε : ℝ) (hε : 0 < ε) : realTest ε (1 / 2) = 1 := by
  unfold realTest dcPositive dcNegative
  have hn : ε ≠ 0 := ne_of_gt hε
  have he1 : (1 / 2 : ℝ) - (1 / 2 - ε) = ε := by ring
  have he2 : (1 / 2 : ℝ) - (1 / 2 + ε) = -ε := by ring
  rw [he1, he2]
  simp [abs_of_pos hε]
  field_simp
  ring

theorem realTest_left (ε : ℝ) (hε : 0 < ε) : realTest ε (1 / 2 - ε) = -1 := by
  unfold realTest dcPositive dcNegative
  have he1 : (1 / 2 - ε) - (1 / 2 + ε) = -(2 * ε) := by ring
  have he2 : (1 / 2 - ε) - 1 / 2 = -ε := by ring
  rw [he1, he2]
  simp [abs_of_pos hε, abs_of_nonneg (show 0 ≤ 2 * ε by positivity)]

theorem realTest_right (ε : ℝ) (hε : 0 < ε) : realTest ε (1 / 2 + ε) = -1 := by
  unfold realTest dcPositive dcNegative
  have he1 : (1 / 2 + ε) - (1 / 2 - ε) = 2 * ε := by ring
  have he2 : (1 / 2 + ε) - 1 / 2 = ε := by ring
  rw [he1, he2]
  simp [abs_of_pos hε, abs_of_nonneg (show 0 ≤ 2 * ε by positivity)]

theorem test_center (ε : ℝ) (hε : 0 < ε) : test ε center = 1 :=
  realTest_center ε hε

theorem test_left (ε : ℝ) (hε : ε ∈ Icc (0 : ℝ) (1 / 2)) (hpos : 0 < ε) :
    test ε (left ε hε) = -1 := realTest_left ε hpos

theorem test_right (ε : ℝ) (hε : ε ∈ Icc (0 : ℝ) (1 / 2)) (hpos : 0 < ε) :
    test ε (right ε hε) = -1 := realTest_right ε hpos

theorem integral_test_uninformative (ε : ℝ) (hε : 0 < ε) :
    ∫ x, test ε x ∂uninformative = 1 := by
  rw [integral_uninformative, test_center ε hε]

theorem integral_test_spread (ε : ℝ) (hε : ε ∈ Icc (0 : ℝ) (1 / 2))
    (hpos : 0 < ε) : ∫ x, test ε x ∂spread ε hε = -1 := by
  rw [integral_spread, test_left ε hε hpos, test_right ε hε hpos]
  norm_num

/-- All integrals exist as ordinary real integrals; their difference is exactly minus two. -/
theorem integral_test_difference (ε : ℝ) (hε : ε ∈ Icc (0 : ℝ) (1 / 2))
    (hpos : 0 < ε) :
    (∫ x, test ε x ∂spread ε hε) - (∫ x, test ε x ∂uninformative) = -2 := by
  rw [integral_test_spread ε hε hpos, integral_test_uninformative ε hpos]
  norm_num

theorem abs_integral_test_difference (ε : ℝ) (hε : ε ∈ Icc (0 : ℝ) (1 / 2))
    (hpos : 0 < ε) :
    |(∫ x, test ε x ∂spread ε hε) - (∫ x, test ε x ∂uninformative)| = 2 := by
  rw [integral_test_difference ε hε hpos]
  norm_num

/-- The exact test class: a difference of two continuous convex functions on the
posterior interval, with the difference bounded in absolute value by one. -/
def NormalizedDCTest (v : Posterior → ℝ) : Prop :=
  (∃ vPlus vMinus : ℝ → ℝ,
    ContinuousOn vPlus (Icc (0 : ℝ) 1) ∧ ContinuousOn vMinus (Icc (0 : ℝ) 1) ∧
    ConvexOn ℝ (Icc (0 : ℝ) 1) vPlus ∧ ConvexOn ℝ (Icc (0 : ℝ) 1) vMinus ∧
    ∀ x : Posterior, v x = vPlus x - vMinus x) ∧ ∀ x, |v x| ≤ 1

theorem test_normalizedDC (ε : ℝ) (hε : 0 < ε) : NormalizedDCTest (test ε) := by
  refine ⟨⟨dcPositive ε, dcNegative ε, (dcPositive_continuous ε).continuousOn,
    (dcNegative_continuous ε).continuousOn, ?_, ?_, fun _ => rfl⟩,
    test_abs_le_one ε hε⟩
  · exact (dcPositive_convex ε hε).subset (subset_univ _) (convex_Icc _ _)
  · exact (dcNegative_convex ε hε).subset (subset_univ _) (convex_Icc _ _)

theorem abs_integral_difference_le_two (ε : ℝ) (hε : ε ∈ Icc (0 : ℝ) (1 / 2))
    (v : Posterior → ℝ) (hv : ∀ x, |v x| ≤ 1) :
    |(∫ x, v x ∂spread ε hε) - (∫ x, v x ∂uninformative)| ≤ 2 := by
  rw [integral_spread, integral_uninformative, abs_le]
  have hc := abs_le.mp (hv center)
  have hl := abs_le.mp (hv (left ε hε))
  have hr := abs_le.mp (hv (right ε hε))
  constructor <;> linarith

noncomputable def dcDiscrepancy (μ ν : Measure Posterior) : ℝ :=
  sSup {r : ℝ | ∃ v : Posterior → ℝ, NormalizedDCTest v ∧
    r = |(∫ x, v x ∂μ) - (∫ x, v x ∂ν)|}

/-- The normalized DC supremum in the information-space lemma is exactly two,
not zero, for every nondegenerate symmetric spread. -/
theorem dcDiscrepancy_spread_eq_two (ε : ℝ) (hε : ε ∈ Icc (0 : ℝ) (1 / 2))
    (hpos : 0 < ε) : dcDiscrepancy (spread ε hε) uninformative = 2 := by
  unfold dcDiscrepancy
  have hmem : (2 : ℝ) ∈ {r : ℝ | ∃ v : Posterior → ℝ, NormalizedDCTest v ∧
      r = |(∫ x, v x ∂spread ε hε) - (∫ x, v x ∂uninformative)|} := by
    exact ⟨test ε, test_normalizedDC ε hpos, (abs_integral_test_difference ε hε hpos).symm⟩
  have hub : ∀ r ∈ {r : ℝ | ∃ v : Posterior → ℝ, NormalizedDCTest v ∧
      r = |(∫ x, v x ∂spread ε hε) - (∫ x, v x ∂uninformative)|}, r ≤ 2 := by
    rintro r ⟨v, hv, rfl⟩
    exact abs_integral_difference_le_two ε hε v hv.2
  exact le_antisymm (csSup_le ⟨2, hmem⟩ hub) (le_csSup ⟨2, hub⟩ hmem)

/-- Symmetric posterior spreads form a convex-order chain. -/
theorem integral_spread_mono (ε δ : ℝ)
    (hε : ε ∈ Icc (0 : ℝ) (1 / 2)) (hδ : δ ∈ Icc (0 : ℝ) (1 / 2))
    (hεδ : ε ≤ δ) (v : ℝ → ℝ) (hv : ConvexOn ℝ (Icc (0 : ℝ) 1) v) :
    (∫ x, v x ∂spread ε hε) ≤ ∫ x, v x ∂spread δ hδ := by
  by_cases hδzero : δ = 0
  · have hεzero : ε = 0 := by linarith [hε.1]
    subst ε
    subst δ
    rfl
  have hδpos : 0 < δ := lt_of_le_of_ne hδ.1 (Ne.symm hδzero)
  let a : ℝ := (δ + ε) / (2 * δ)
  let b : ℝ := (δ - ε) / (2 * δ)
  have ha : 0 ≤ a := div_nonneg (by linarith [hε.1]) (by positivity)
  have hb : 0 ≤ b := div_nonneg (by linarith) (by positivity)
  have hab : a + b = 1 := by
    dsimp [a, b]
    field_simp
    ring
  have hba : b + a = 1 := by linarith
  have hleft : a * (1 / 2 - δ) + b * (1 / 2 + δ) = 1 / 2 - ε := by
    dsimp [a, b]
    field_simp
    ring
  have hright : b * (1 / 2 - δ) + a * (1 / 2 + δ) = 1 / 2 + ε := by
    dsimp [a, b]
    field_simp
    ring
  have hl := hv.2 (left δ hδ).property (right δ hδ).property ha hb hab
  have hr := hv.2 (left δ hδ).property (right δ hδ).property hb ha hba
  simp only [left, right, smul_eq_mul] at hl hr
  rw [hleft] at hl
  rw [hright] at hr
  have hsum : v (1 / 2 - ε) + v (1 / 2 + ε) ≤ v (1 / 2 - δ) + v (1 / 2 + δ) := by
    calc
      _ ≤ (a * v (1 / 2 - δ) + b * v (1 / 2 + δ)) +
          (b * v (1 / 2 - δ) + a * v (1 / 2 + δ)) := add_le_add hl hr
      _ = (a + b) * (v (1 / 2 - δ) + v (1 / 2 + δ)) := by ring
      _ = _ := by rw [hab, one_mul]
  rw [integral_spread, integral_spread]
  simp only [left, right]
  linarith

/-- Every mean-preserving symmetric spread dominates the uninformative law. -/
theorem integral_uninformative_le_spread (ε : ℝ)
    (hε : ε ∈ Icc (0 : ℝ) (1 / 2))
    (v : ℝ → ℝ) (hv : ConvexOn ℝ (Icc (0 : ℝ) 1) v) :
    (∫ x, v x ∂uninformative) ≤ ∫ x, v x ∂spread ε hε := by
  have h := hv.2 (left ε hε).property (right ε hε).property
    (show (0 : ℝ) ≤ 1 / 2 by norm_num) (show (0 : ℝ) ≤ 1 / 2 by norm_num)
    (show (1 / 2 : ℝ) + 1 / 2 = 1 by norm_num)
  simp only [left, right, smul_eq_mul] at h
  have heq : (1 / 2 : ℝ) * (1 / 2 - ε) + 1 / 2 * (1 / 2 + ε) = 1 / 2 := by ring
  rw [heq] at h
  rw [integral_uninformative, integral_spread]
  simp only [center, left, right]
  linarith

end Envelope.InformationCounterexample
