import Mathlib.MeasureTheory.Function.AbsolutelyContinuous
import Mathlib.MeasureTheory.Integral.DominatedConvergence
import Mathlib.Topology.Instances.ENNReal.Lemmas
import Mathlib.Tactic

/-!
# Endpoint extension and absolute continuity

An envelope identity on every interior pair extends to the closed interval when
the value is continuous and the derivative is integrable. A bounded derivative
then makes the value Lipschitz, hence absolutely continuous. These are independent
consequences of the envelope identity, not assumptions of the converse.
-/

open Set MeasureTheory
open scoped Interval NNReal

namespace Envelope

/-- It suffices to verify an envelope increment for ordered interior endpoints. -/
theorem interior_envelope_of_ordered (V D : ℝ → ℝ)
    (hEnv : ∀ r ∈ Ioo (0 : ℝ) 1, ∀ t ∈ Ioo (0 : ℝ) 1, r < t →
      V t - V r = ∫ s in r..t, D s) :
    ∀ r ∈ Ioo (0 : ℝ) 1, ∀ t ∈ Ioo (0 : ℝ) 1,
      V t - V r = ∫ s in r..t, D s := by
  intro r hr t ht
  rcases lt_trichotomy r t with hrt | rfl | htr
  · exact hEnv r hr t ht hrt
  · simp
  · have he := hEnv t ht r hr htr
    rw [intervalIntegral.integral_symm]
    linarith

/-- An integral envelope on the open interval extends to all endpoints.
Only integrability of the diagonal derivative and continuity of the value are needed. -/
theorem envelope_extends_to_endpoints (V D : ℝ → ℝ)
    (hV : ContinuousOn V (Icc (0 : ℝ) 1))
    (hD : IntervalIntegrable D volume 0 1)
    (hEnv : ∀ r ∈ Ioo (0 : ℝ) 1, ∀ t ∈ Ioo (0 : ℝ) 1,
      V t - V r = ∫ s in r..t, D s) :
    ∀ r ∈ Icc (0 : ℝ) 1, ∀ t ∈ Icc (0 : ℝ) 1,
      V t - V r = ∫ s in r..t, D s := by
  let c : ℝ := 1 / 2
  have hc : c ∈ Ioo (0 : ℝ) 1 := by norm_num [c]
  have hc' : c ∈ uIcc (0 : ℝ) 1 := by norm_num [c, uIcc]
  have hP : ContinuousOn (fun t => V c + ∫ s in c..t, D s) (Icc (0 : ℝ) 1) := by
    apply continuousOn_const.add
    simpa only [uIcc_of_le (by norm_num : (0 : ℝ) ≤ 1)] using
      intervalIntegral.continuousOn_primitive_interval' hD hc'
  have heq : EqOn V (fun t => V c + ∫ s in c..t, D s) (Ioo (0 : ℝ) 1) := by
    intro t ht
    linarith [hEnv c hc t ht]
  have heq' : EqOn V (fun t => V c + ∫ s in c..t, D s) (Icc (0 : ℝ) 1) :=
    heq.of_subset_closure hV hP Ioo_subset_Icc_self
      (by rw [closure_Ioo (by norm_num : (0 : ℝ) ≠ 1)])
  have hint : ∀ t ∈ Icc (0 : ℝ) 1, IntervalIntegrable D volume c t := by
    intro t ht
    apply hD.mono_set
    exact uIcc_subset_uIcc hc'
      (by simpa only [uIcc_of_le (by norm_num : (0 : ℝ) ≤ 1)] using ht)
  intro r hr t ht
  rw [heq' ht, heq' hr]
  simpa only [add_sub_add_left_eq_sub] using
    intervalIntegral.integral_interval_sub_left (hint t ht) (hint r hr)

/-- A bounded diagonal derivative makes the continuous envelope value Lipschitz,
including at the endpoints. -/
theorem envelope_lipschitz_of_interior (V D : ℝ → ℝ) (L : ℝ≥0)
    (hV : ContinuousOn V (Icc (0 : ℝ) 1))
    (hD : IntervalIntegrable D volume 0 1)
    (hbound : ∀ s ∈ Icc (0 : ℝ) 1, ‖D s‖ ≤ (L : ℝ))
    (hEnv : ∀ r ∈ Ioo (0 : ℝ) 1, ∀ t ∈ Ioo (0 : ℝ) 1,
      V t - V r = ∫ s in r..t, D s) :
    LipschitzOnWith L V (Icc (0 : ℝ) 1) := by
  rw [lipschitzOnWith_iff_dist_le_mul]
  intro r hr t ht
  have he := envelope_extends_to_endpoints V D hV hD hEnv t ht r hr
  have hb := intervalIntegral.norm_integral_le_of_norm_le_const
    (a := t) (b := r) (f := D) (C := (L : ℝ))
    (fun s hs => hbound s ((uIcc_subset_Icc ht hr) (uIoc_subset_uIcc hs)))
  rw [← he] at hb
  simpa only [Real.dist_eq, Real.norm_eq_abs] using hb

/-- The repaired converse implies absolute continuity of the value; it need not
assume absolute continuity as an additional hypothesis. -/
theorem envelope_absolutelyContinuous_of_interior (V D : ℝ → ℝ) (L : ℝ≥0)
    (hV : ContinuousOn V (Icc (0 : ℝ) 1))
    (hD : IntervalIntegrable D volume 0 1)
    (hbound : ∀ s ∈ Icc (0 : ℝ) 1, ‖D s‖ ≤ (L : ℝ))
    (hEnv : ∀ r ∈ Ioo (0 : ℝ) 1, ∀ t ∈ Ioo (0 : ℝ) 1,
      V t - V r = ∫ s in r..t, D s) :
    AbsolutelyContinuousOnInterval V 0 1 := by
  apply LipschitzOnWith.absolutelyContinuousOnInterval (K := L)
  simpa only [uIcc_of_le (by norm_num : (0 : ℝ) ≤ 1)] using
    envelope_lipschitz_of_interior V D L hV hD hbound hEnv

end Envelope
