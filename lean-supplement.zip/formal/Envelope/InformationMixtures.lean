import Envelope.InformationCounterexample

/-! Prior-preserving mixtures and the extreme information laws. -/

open Set MeasureTheory
open scoped ENNReal
noncomputable section

namespace Envelope.InformationCounterexample

def mixMeasure (α : ℝ) (z w : Law) : Measure Posterior :=
  ENNReal.ofReal (1 - α) • z.measure + ENNReal.ofReal α • w.measure

theorem mixMeasure_probability (α : ℝ) (hα : α ∈ Icc (0 : ℝ) 1) (z w : Law) :
    IsProbabilityMeasure (mixMeasure α z w) := by
  constructor
  simp only [mixMeasure, Measure.add_apply, Measure.smul_apply,
    measure_univ, smul_eq_mul, mul_one]
  rw [← ENNReal.ofReal_add (by linarith [hα.2]) hα.1]
  norm_num

theorem integral_mixMeasure (α : ℝ) (hα : α ∈ Icc (0 : ℝ) 1) (z w : Law)
    (v : Posterior → ℝ) (hz : Integrable v z.measure) (hw : Integrable v w.measure) :
    (∫ x, v x ∂mixMeasure α z w) =
      (1 - α) * (∫ x, v x ∂z.measure) + α * (∫ x, v x ∂w.measure) := by
  unfold mixMeasure
  rw [integral_add_measure (hz.smul_measure ENNReal.ofReal_ne_top)
    (hw.smul_measure ENNReal.ofReal_ne_top)]
  simp only [integral_smul_measure, ENNReal.toReal_ofReal hα.1,
    ENNReal.toReal_ofReal (show 0 ≤ 1 - α by linarith [hα.2]), smul_eq_mul]

def mixLaw (α : ℝ) (hα : α ∈ Icc (0 : ℝ) 1) (z w : Law) : Law where
  measure := mixMeasure α z w
  probability := mixMeasure_probability α hα z w
  mean := by
    rw [integral_mixMeasure α hα z w _ (integral_coordinate _) (integral_coordinate _),
      z.mean, w.mean]
    ring

theorem integral_mixLaw (α : ℝ) (hα : α ∈ Icc (0 : ℝ) 1) (z w : Law)
    {v : ℝ → ℝ} (hv : ContinuousOn v (Icc (0 : ℝ) 1)) :
    (∫ x, v x ∂(mixLaw α hα z w).measure) =
      (1 - α) * (∫ x, v x ∂z.measure) + α * (∫ x, v x ∂w.measure) :=
  integral_mixMeasure α hα z w _ (integral_continuous _ hv) (integral_continuous _ hv)

def fullLaw : Law := spreadLaw (1 / 2) (by norm_num)

theorem integral_fullLaw (v : ℝ → ℝ) :
    (∫ x, v x ∂fullLaw.measure) = (v 0 + v 1) / 2 := by
  change (∫ x, v x ∂spread (1 / 2) _) = _
  rw [integral_spread]
  norm_num [left, right]

/-- The law revealing the binary state dominates every prior-preserving law. -/
theorem le_full (z : Law) : Blackwell z fullLaw := by
  intro v hv hc
  have hp : ∀ x : Posterior, v x ≤ v 0 + (v 1 - v 0) * (x : ℝ) := by
    intro x
    have hx := hc.2 (show (0 : ℝ) ∈ Icc (0 : ℝ) 1 by norm_num)
      (show (1 : ℝ) ∈ Icc (0 : ℝ) 1 by norm_num)
      (show 0 ≤ 1 - (x : ℝ) by linarith [x.property.2]) x.property.1
      (show 1 - (x : ℝ) + (x : ℝ) = 1 by ring)
    simp only [smul_eq_mul, mul_zero, mul_one, zero_add] at hx
    nlinarith
  have hbound : Integrable (fun x : Posterior => v 0 + (v 1 - v 0) * (x : ℝ)) z.measure :=
    (integrable_const _).add ((integral_coordinate _).const_mul _)
  have hint := integral_mono (integral_continuous z.measure hv) hbound hp
  rw [integral_add (integrable_const _) ((integral_coordinate _).const_mul _),
    integral_const_mul, z.mean] at hint
  simp only [integral_const, probReal_univ, one_smul] at hint
  rw [integral_fullLaw]
  linarith

theorem mix_le_of_le (α : ℝ) (hα : α ∈ Icc (0 : ℝ) 1) (z w : Law)
    (hwz : Blackwell w z) : Blackwell (mixLaw α hα z w) z := by
  intro v hv hc
  rw [integral_mixLaw α hα z w hv]
  have h := hwz v hv hc
  nlinarith [mul_nonneg hα.1 (sub_nonneg.mpr h)]

theorem le_mix_of_le (α : ℝ) (hα : α ∈ Icc (0 : ℝ) 1) (z w : Law)
    (hzw : Blackwell z w) : Blackwell z (mixLaw α hα z w) := by
  intro v hv hc
  rw [integral_mixLaw α hα z w hv]
  have h := hzw v hv hc
  nlinarith [mul_nonneg hα.1 (sub_nonneg.mpr h)]

theorem mix_base_le (α : ℝ) (hα : α ∈ Icc (0 : ℝ) 1) (z : Law) :
    Blackwell (mixLaw α hα z baseLaw) z := mix_le_of_le α hα z baseLaw (base_le z)

theorem le_mix_full (α : ℝ) (hα : α ∈ Icc (0 : ℝ) 1) (z : Law) :
    Blackwell z (mixLaw α hα z fullLaw) := le_mix_of_le α hα z fullLaw (le_full z)

/-- Mixing a nonminimal law with the uninformative law moves strictly downward. -/
theorem strict_mix_base (α : ℝ) (hα : α ∈ Icc (0 : ℝ) 1) (z : Law)
    (hpos : 0 < α) (hz : ¬ Blackwell z baseLaw) :
    StrictBlackwell (mixLaw α hα z baseLaw) z := by
  refine ⟨mix_base_le α hα z, ?_⟩
  intro hreverse
  apply hz
  intro v hv hc
  have h := hreverse v hv hc
  rw [integral_mixLaw α hα z baseLaw hv] at h
  nlinarith

/-- Mixing a nonmaximal law with full revelation moves strictly upward. -/
theorem strict_mix_full (α : ℝ) (hα : α ∈ Icc (0 : ℝ) 1) (z : Law)
    (hpos : 0 < α) (hz : ¬ Blackwell fullLaw z) :
    StrictBlackwell z (mixLaw α hα z fullLaw) := by
  refine ⟨le_mix_full α hα z, ?_⟩
  intro hreverse
  apply hz
  intro v hv hc
  have h := hreverse v hv hc
  rw [integral_mixLaw α hα z fullLaw hv] at h
  nlinarith

end Envelope.InformationCounterexample
