import Envelope.QuadraticNull
import Mathlib.MeasureTheory.Function.UniformIntegrable

/-!
# Measurable uniformly integrable supremum of fixed-action quotients

An arbitrary supremum of measurable functions need not be measurable. For the
quadratic construction, the supremum is computed explicitly. Its measurability
therefore does not rely on the invalid arbitrary-supremum principle.
-/

open MeasureTheory Set
open scoped ENNReal NNReal

namespace Envelope.QuadraticNull

noncomputable def quotientValues (A : Set ℝ) (s h : ℝ) : Set ℝ :=
  {q | ∃ u ∈ Icc (0 : ℝ) 1, ∃ y ∈ Icc (0 : ℝ) 1,
    q = |(payoff A (u, y) (s + h) - payoff A (u, y) s) / h|}

def quotientCap (s h : ℝ) : ℝ := max |2 * s + h| |2 * s + h - 2|

theorem payoff_quotient_eq (A : Set ℝ) (u y s h : ℝ) (hh : h ≠ 0) :
    (payoff A (u, y) (s + h) - payoff A (u, y) s) / h =
      -(A.indicator (fun _ => (1 : ℝ)) y) * (2 * s + h - 2 * u) := by
  unfold payoff
  dsimp
  field_simp
  ring

theorem affine_abs_le_quotientCap (s h u : ℝ) (hu : u ∈ Icc (0 : ℝ) 1) :
    |2 * s + h - 2 * u| ≤ quotientCap s h := by
  apply abs_le.mpr
  have h₀ : |2 * s + h| ≤ quotientCap s h := le_max_left _ _
  have h₁ : |2 * s + h - 2| ≤ quotientCap s h := le_max_right _ _
  constructor
  · linarith [neg_le_abs (2 * s + h - 2), hu.2]
  · linarith [le_abs_self (2 * s + h), hu.1]

/-- The exact supremum is a maximum of two continuous scalar functions. -/
theorem quotientSup_eq (A : Set ℝ) (hA : A.Nonempty)
    (hAI : A ⊆ Icc (0 : ℝ) 1) (s h : ℝ) (hh : h ≠ 0) :
    sSup (quotientValues A s h) = quotientCap s h := by
  classical
  apply IsGreatest.csSup_eq
  constructor
  · obtain ⟨y, hy⟩ := hA
    rcases le_total |2 * s + h| |2 * s + h - 2| with he |he
    · refine ⟨1, by constructor <;> norm_num, y, hAI hy, ?_⟩
      rw [payoff_quotient_eq A 1 y s h hh]
      simp only [quotientCap, indicator_of_mem hy, max_eq_right he,
        neg_mul, one_mul, abs_neg, mul_one]
    · refine ⟨0, by constructor <;> norm_num, y, hAI hy, ?_⟩
      rw [payoff_quotient_eq A 0 y s h hh]
      simp only [quotientCap, indicator_of_mem hy, max_eq_left he,
        neg_mul, one_mul, abs_neg, mul_zero, sub_zero]
  · rintro q ⟨u, hu, y, _, rfl⟩
    rw [payoff_quotient_eq A u y s h hh]
    by_cases hy : y ∈ A
    · simpa only [indicator_of_mem hy, neg_mul, one_mul, abs_neg]
        using affine_abs_le_quotientCap s h u hu
    · simp only [indicator_of_notMem hy, neg_zero, zero_mul, abs_zero]
      exact (abs_nonneg _).trans (le_max_left _ _)

theorem measurable_quotientSup (A : Set ℝ) (hA : A.Nonempty)
    (hAI : A ⊆ Icc (0 : ℝ) 1) (h : ℝ) (hh : h ≠ 0) :
    Measurable (fun s => sSup (quotientValues A s h)) := by
  simp_rw [quotientSup_eq A hA hAI _ h hh]
  unfold quotientCap
  fun_prop

def admissibleShift (h : ℝ) : Set ℝ :=
  {s | s ∈ Icc (0 : ℝ) 1 ∧ s + h ∈ Icc (0 : ℝ) 1}

/-- Zero extension outside the domain where both type arguments are admissible.
The value at shift zero is an innocuous extension of the nonzero-shift family. -/
noncomputable def extendedQuotientSup (h s : ℝ) : ℝ :=
  (admissibleShift h).indicator (fun s => quotientCap s h) s

theorem measurableSet_admissibleShift (h : ℝ) : MeasurableSet (admissibleShift h) := by
  exact measurableSet_Icc.inter (measurableSet_Icc.preimage (measurable_id.add_const h))

theorem measurable_extendedQuotientSup (h : ℝ) : Measurable (extendedQuotientSup h) := by
  apply Measurable.indicator _ (measurableSet_admissibleShift h)
  unfold quotientCap
  fun_prop

theorem quotientCap_bound (s h : ℝ) (hs : s ∈ admissibleShift h) :
    |quotientCap s h| ≤ 2 := by
  have hsum : 0 ≤ 2 * s + h ∧ 2 * s + h ≤ 2 := by
    constructor <;> linarith [hs.1.1, hs.1.2, hs.2.1, hs.2.2]
  have h₀ : |2 * s + h| ≤ 2 := abs_le.mpr ⟨by linarith, hsum.2⟩
  have h₁ : |2 * s + h - 2| ≤ 2 := abs_le.mpr ⟨by linarith, by linarith⟩
  rw [abs_of_nonneg ((abs_nonneg _).trans (le_max_left _ _))]
  exact max_le h₀ h₁

theorem extendedQuotientSup_bound (h s : ℝ) : |extendedQuotientSup h s| ≤ 2 := by
  classical
  by_cases hs : s ∈ admissibleShift h
  · simpa [extendedQuotientSup, hs] using quotientCap_bound s h hs
  · simp [extendedQuotientSup, hs]

/-- The measurable quotient-supremum family satisfies mathlib's full
probabilistic uniform-integrability predicate at exponent one. -/
theorem extendedQuotientSup_uniformIntegrable
    (μ : Measure ℝ) [IsFiniteMeasure μ] : UniformIntegrable extendedQuotientSup 1 μ := by
  apply uniformIntegrable_of (by norm_num) (by norm_num)
    (fun h => (measurable_extendedQuotientSup h).aestronglyMeasurable)
  intro ε hε
  refine ⟨3, fun h => ?_⟩
  have hempty : {s | (3 : ℝ≥0) ≤ ‖extendedQuotientSup h s‖₊} = ∅ := by
    apply Set.eq_empty_iff_forall_notMem.mpr
    intro s hs
    have hnorm : 3 ≤ |extendedQuotientSup h s| := by
      exact_mod_cast hs
    linarith [extendedQuotientSup_bound h s]
  rw [hempty]
  simp

/-- The actual supremum family is indexed only by nonzero shifts. -/
noncomputable def actualQuotientSup (A : Set ℝ) (h : {h : ℝ // h ≠ 0}) (s : ℝ) : ℝ :=
  (admissibleShift h.val).indicator (fun s => sSup (quotientValues A s h.val)) s

theorem actualQuotientSup_eq (A : Set ℝ) (hA : A.Nonempty)
    (hAI : A ⊆ Icc (0 : ℝ) 1) (h : {h : ℝ // h ≠ 0}) :
    actualQuotientSup A h = extendedQuotientSup h.val := by
  funext s
  simp only [actualQuotientSup, quotientSup_eq A hA hAI _ h.val h.property,
    extendedQuotientSup]

/-- Measurability of the actual zero-extended supremum, including its
admissible-domain cutoff. -/
theorem measurable_actualQuotientSup (A : Set ℝ) (hA : A.Nonempty)
    (hAI : A ⊆ Icc (0 : ℝ) 1) (h : {h : ℝ // h ≠ 0}) :
    Measurable (actualQuotientSup A h) := by
  rw [actualQuotientSup_eq A hA hAI h]
  exact measurable_extendedQuotientSup h.val

/-- Uniform integrability is proved for the actual supremum over unit-square
actions, not merely for a dominating family. -/
theorem actualQuotientSup_uniformIntegrable (A : Set ℝ) (hA : A.Nonempty)
    (hAI : A ⊆ Icc (0 : ℝ) 1) (μ : Measure ℝ) [IsFiniteMeasure μ] :
    UniformIntegrable (actualQuotientSup A) 1 μ := by
  have heq : actualQuotientSup A =
      (fun h : {h : ℝ // h ≠ 0} => extendedQuotientSup h.val) := by
    funext h
    exact actualQuotientSup_eq A hA hAI h
  rw [heq]
  obtain ⟨hm, hu, C, hC⟩ := extendedQuotientSup_uniformIntegrable μ
  refine ⟨fun h => hm h.val, ?_, C, fun h => hC h.val⟩
  intro ε hε
  obtain ⟨δ, hδ, hbound⟩ := hu hε
  exact ⟨δ, hδ, fun h => hbound h.val⟩

theorem actualQuotientSup_uniformIntegrable_unitInterval
    (A : Set ℝ) (hA : A.Nonempty) (hAI : A ⊆ Icc (0 : ℝ) 1) :
    UniformIntegrable (actualQuotientSup A) 1 (volume.restrict (Icc (0 : ℝ) 1)) :=
  actualQuotientSup_uniformIntegrable A hA hAI _

/-- One and the same constructed primitive has measurable, uniformly
integrable fixed-action quotient suprema and nonintegrable selected shifts. -/
theorem exists_uniformIntegrable_suprema_with_nonintegrable_shifts :
    ∃ A : Set ℝ,
      A ⊆ Icc (1 / 3 : ℝ) (2 / 3 : ℝ) ∧
      (∀ h, Measurable (actualQuotientSup A h)) ∧
      UniformIntegrable (actualQuotientSup A) 1 (volume.restrict (Icc (0 : ℝ) 1)) ∧
      (∀ m, |m| < 1 / 12 → m ≠ 0 →
        ¬ Integrable (fun s => payoff A (diagonal (s + m)) s)
          (volume.restrict (Icc (1 / 4 : ℝ) (3 / 4 : ℝ)))) := by
  obtain ⟨A, hA, hAn⟩ := exists_nonmeasurable_interior
  have hne : A.Nonempty := by
    by_contra hn
    have hAe : A = ∅ := Set.not_nonempty_iff_eq_empty.mp hn
    apply hAn
    rw [hAe]
    exact nullMeasurableSet_empty
  have hAI : A ⊆ Icc (0 : ℝ) 1 := by
    intro a ha
    have hi := hA ha
    constructor <;> linarith [hi.1, hi.2]
  exact ⟨A, hA, measurable_actualQuotientSup A hne hAI,
    actualQuotientSup_uniformIntegrable_unitInterval A hne hAI,
    shifted_payoff_not_integrable A hA hAn⟩

end Envelope.QuadraticNull
