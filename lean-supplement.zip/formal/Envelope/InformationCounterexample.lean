import Envelope.InformationWitness
import Mathlib.Analysis.Convex.Integral
import Mathlib.MeasureTheory.Function.LocallyIntegrable
import Mathlib.Topology.Order
import Mathlib.Analysis.SpecificLimits.Basic

open Set MeasureTheory Filter TopologicalSpace
open scoped Topology ENNReal
noncomputable section
namespace Envelope.InformationCounterexample

/-- All posterior laws on the binary simplex with the fixed prior 1/2. -/
structure Law where
  measure : Measure Posterior
  probability : IsProbabilityMeasure measure
  mean : ∫ x, (x : ℝ) ∂measure = 1 / 2

instance (z : Law) : IsProbabilityMeasure z.measure := z.probability

def baseLaw : Law := ⟨uninformative, inferInstance, mean_uninformative⟩
def spreadLaw (ε : ℝ) (hε : ε ∈ Icc (0 : ℝ) (1/2)) : Law :=
  ⟨spread ε hε, inferInstance, mean_spread ε hε⟩

/-- Blackwell order is tested by all continuous convex functions on the posterior interval. -/
def Blackwell (z w : Law) : Prop :=
  ∀ v : ℝ → ℝ, ContinuousOn v (Icc 0 1) → ConvexOn ℝ (Icc 0 1) v →
    (∫ x, v x ∂z.measure) ≤ ∫ x, v x ∂w.measure

def StrictBlackwell (z w : Law) : Prop := Blackwell z w ∧ ¬ Blackwell w z

lemma integral_continuous (μ : Measure Posterior) [IsFiniteMeasure μ]
    {v : ℝ → ℝ} (hv : ContinuousOn v (Icc 0 1)) :
    Integrable (fun x : Posterior => v x) μ := by
  exact (hv.restrict).integrable_of_hasCompactSupport (HasCompactSupport.of_compactSpace _)

lemma integral_coordinate (μ : Measure Posterior) [IsFiniteMeasure μ] :
    Integrable (fun x : Posterior => (x : ℝ)) μ :=
  integral_continuous μ continuousOn_id

lemma base_le (z : Law) : Blackwell baseLaw z := by
  intro v hv hc
  change (∫ x, v x ∂uninformative) ≤ _
  rw [integral_uninformative]
  change v (1/2) ≤ _
  rw [← z.mean]
  exact hc.map_integral_le hv isClosed_Icc
    (Eventually.of_forall fun x => x.property) (integral_coordinate _)
    (integral_continuous _ hv)

lemma blackwell_refl (z : Law) : Blackwell z z := fun _ _ _ => le_rfl
lemma blackwell_trans {z w u : Law} (hzw : Blackwell z w) (hwu : Blackwell w u) :
    Blackwell z u := fun v hv hc => (hzw v hv hc).trans (hwu v hv hc)

/-- A convex function evaluated at two points symmetric around the barycenter
is bounded by its expectation under a two-point law straddling those points. -/
lemma convex_symmetric_bound {v : ℝ → ℝ} (hv : ConvexOn ℝ (Icc 0 1) v)
    {a b w ε : ℝ} (ha : a ∈ Icc (0:ℝ) 1) (hb : b ∈ Icc (0:ℝ) 1)
    (hab : a < b) (hw : 0 ≤ w) (hw' : w ≤ 1)
    (hmean : w*a+(1-w)*b=1/2) (hε : 0 ≤ ε)
    (hleft : ε ≤ w*(b-a)) (hright : ε ≤ (1-w)*(b-a)) :
    (v (1/2-ε)+v (1/2+ε))/2 ≤ w*v a+(1-w)*v b := by
  let d := ε/(b-a)
  have hd : 0 ≤ d := div_nonneg hε (sub_pos.mpr hab).le
  have hdw : d ≤ w := (div_le_iff₀ (sub_pos.mpr hab)).2 hleft
  have hdw' : d ≤ 1-w := (div_le_iff₀ (sub_pos.mpr hab)).2 hright
  have hdl : d*(b-a)=ε := div_mul_cancel₀ _ (sub_ne_zero.mpr hab.ne')
  have h1 := hv.2 ha hb (show 0 ≤ w+d by linarith)
    (show 0 ≤ 1-w-d by linarith) (show (w+d)+(1-w-d)=1 by ring)
  have h2 := hv.2 ha hb (show 0 ≤ w-d by linarith)
    (show 0 ≤ 1-w+d by linarith) (show (w-d)+(1-w+d)=1 by ring)
  simp only [smul_eq_mul] at h1 h2
  have he1 : (w+d)*a+(1-w-d)*b=1/2-ε := by nlinarith
  have he2 : (w-d)*a+(1-w+d)*b=1/2+ε := by nlinarith
  rw [he1] at h1
  rw [he2] at h2
  nlinarith

/-- A nontrivial law admits a measurable split whose conditional means are distinct. -/
lemma exists_split (z : Law) (hz : ¬ Blackwell z baseLaw) :
    ∃ s : Set Posterior, MeasurableSet s ∧ z.measure s ≠ 0 ∧ z.measure sᶜ ≠ 0 ∧
      (⨍ x in s, (x:ℝ) ∂z.measure) < (⨍ x in sᶜ, (x:ℝ) ∂z.measure) := by
  have hnc : ¬ (fun x : Posterior => (x:ℝ)) =ᵐ[z.measure]
      Function.const Posterior (⨍ x, (x:ℝ) ∂z.measure) := by
    intro h
    apply hz
    intro v hv hc
    simp only [average_eq_integral, z.mean] at h
    have he : (fun x : Posterior => v x) =ᵐ[z.measure] fun _ => v (1/2) :=
      h.mono fun x hx => congrArg v hx
    rw [integral_congr_ae he]
    simp [baseLaw, integral_uninformative, center]
  obtain ⟨s, hs, hs0, hsc0, hne⟩ :=
    (ae_eq_const_or_exists_average_ne_compl (integral_coordinate z.measure)).resolve_left hnc
  rcases lt_or_gt_of_ne hne with hlt | hgt
  · exact ⟨s, hs, hs0, hsc0, hlt⟩
  · exact ⟨sᶜ, hs.compl, hsc0, by simpa using hs0, by simpa using hgt⟩

/-- Every nontrivial prior-preserving law dominates all sufficiently small symmetric spreads.
The proof uses an actual measurable partition and Jensen's inequality for its two restrictions. -/
lemma eventually_small_spread_le (z : Law) (hz : ¬ Blackwell z baseLaw) :
    ∃ δ > (0:ℝ), ∀ ε (hε : ε ∈ Icc (0:ℝ) (1/2)), ε ≤ δ →
      Blackwell (spreadLaw ε hε) z := by
  obtain ⟨s, hs, hs0, hsc0, hab⟩ := exists_split z hz
  let a := ⨍ x in s, (x:ℝ) ∂z.measure
  let b := ⨍ x in sᶜ, (x:ℝ) ∂z.measure
  let w := z.measure.real s
  have hw : 0 < w := ENNReal.toReal_pos hs0 (measure_ne_top _ _)
  have hwc : 0 < 1-w := by
    rw [← probReal_compl_eq_one_sub hs]
    exact ENNReal.toReal_pos hsc0 (measure_ne_top _ _)
  have ha : a ∈ Icc (0:ℝ) 1 :=
    (convex_Icc (0:ℝ) 1).set_average_mem isClosed_Icc hs0 (measure_ne_top _ _)
      (Eventually.of_forall fun x => x.property) (integral_coordinate _).integrableOn
  have hb : b ∈ Icc (0:ℝ) 1 :=
    (convex_Icc (0:ℝ) 1).set_average_mem isClosed_Icc hsc0 (measure_ne_top _ _)
      (Eventually.of_forall fun x => x.property) (integral_coordinate _).integrableOn
  have hsplit (g : Posterior → ℝ) (hg : Integrable g z.measure) :
      w*(⨍ x in s, g x ∂z.measure)+(1-w)*(⨍ x in sᶜ, g x ∂z.measure)=
        ∫ x, g x ∂z.measure := by
    have h1 := measure_smul_setAverage (μ:=z.measure) g (s:=s) (measure_ne_top _ _)
    have h2 := measure_smul_setAverage (μ:=z.measure) g (s:=sᶜ) (measure_ne_top _ _)
    simp only [smul_eq_mul, probReal_compl_eq_one_sub hs] at h1 h2
    rw [h1, h2]
    exact integral_add_compl hs hg
  have hm : w*a+(1-w)*b=1/2 := (hsplit _ (integral_coordinate _)).trans z.mean
  have hd1 : 0 < w*(b-a) := mul_pos hw (sub_pos.mpr hab)
  have hd2 : 0 < (1-w)*(b-a) := mul_pos hwc (sub_pos.mpr hab)
  refine ⟨min (w*(b-a)) ((1-w)*(b-a)), lt_min hd1 hd2, ?_⟩
  intro ε hε hεδ v hv hc
  have hj1 := hc.map_set_average_le hv isClosed_Icc hs0 (measure_ne_top _ _)
    (Eventually.of_forall fun x : Posterior => x.property)
    (integral_coordinate z.measure).integrableOn (integral_continuous z.measure hv).integrableOn
  have hj2 := hc.map_set_average_le hv isClosed_Icc hsc0 (measure_ne_top _ _)
    (Eventually.of_forall fun x : Posterior => x.property)
    (integral_coordinate z.measure).integrableOn (integral_continuous z.measure hv).integrableOn
  have hsum : w*v a+(1-w)*v b ≤ ∫ x, v x ∂z.measure := by
    calc
      _ ≤ w*(⨍ x in s, v x ∂z.measure)+(1-w)*(⨍ x in sᶜ, v x ∂z.measure) :=
        add_le_add (mul_le_mul_of_nonneg_left hj1 hw.le)
          (mul_le_mul_of_nonneg_left hj2 hwc.le)
      _ = _ := hsplit _ (integral_continuous _ hv)
  change (∫ x, v x ∂spread ε hε) ≤ _
  rw [integral_spread]
  change (v (1/2-ε)+v (1/2+ε))/2 ≤ _
  exact (convex_symmetric_bound hc ha hb hab hw.le (by linarith) hm hε.1
    (le_trans hεδ (min_le_left _ _)) (le_trans hεδ (min_le_right _ _))).trans hsum

lemma spread_mono {ε η : ℝ} (hε : ε ∈ Icc (0:ℝ) (1/2))
    (hη : η ∈ Icc (0:ℝ) (1/2)) (hεη : ε ≤ η) :
    Blackwell (spreadLaw ε hε) (spreadLaw η hη) := by
  by_cases hη0 : η=0
  · have hε0 : ε=0 := by linarith [hε.1]
    subst ε; subst η
    exact blackwell_refl _
  have hηpos : 0 < η := lt_of_le_of_ne hη.1 (Ne.symm hη0)
  intro v hv hc
  change (∫ x, v x ∂spread ε hε) ≤ ∫ x, v x ∂spread η hη
  rw [integral_spread, integral_spread]
  change (v (1/2-ε)+v (1/2+ε))/2 ≤ (v (1/2-η)+v (1/2+η))/2
  have h := convex_symmetric_bound hc (left η hη).property (right η hη).property
    (show 1/2-η < 1/2+η by linarith) (show (0:ℝ)≤1/2 by norm_num)
    (show (1/2:ℝ)≤1 by norm_num) (show (1/2:ℝ)*(1/2-η)+(1-1/2)*(1/2+η)=1/2 by ring)
    hε.1 (by dsimp [left, right]; linarith) (by dsimp [left, right]; linarith)
  dsimp only [left, right] at h
  linarith

def radius (n : ℕ) : ℝ := (1/4)/((n:ℝ)+1)
lemma radius_pos (n : ℕ) : 0 < radius n := by unfold radius; positivity
lemma radius_mem (n : ℕ) : radius n ∈ Icc (0:ℝ) (1/2) := by
  refine ⟨(radius_pos n).le, ?_⟩
  unfold radius
  rw [div_le_iff₀ (by positivity : (0:ℝ)<(n:ℝ)+1)]
  have hn : (0:ℝ) ≤ n := Nat.cast_nonneg n
  nlinarith
lemma radius_antitone : Antitone radius := by
  intro m n hmn
  exact div_le_div_of_nonneg_left (by norm_num) (by positivity)
    (by exact_mod_cast Nat.add_le_add_right hmn 1)
lemma radius_tendsto : Tendsto radius atTop (𝓝 0) := by
  have h := (tendsto_one_div_add_atTop_nhds_zero_nat (𝕜:=ℝ)).const_mul (1/4:ℝ)
  change Tendsto (fun n : ℕ => (1/4:ℝ)/((n:ℝ)+1)) atTop (𝓝 0)
  simpa [div_eq_mul_inv] using h

def sequenceLaw (n : ℕ) : Law := spreadLaw (radius n) (radius_mem n)

lemma integral_sequence_tendsto {v : ℝ → ℝ} (hv : ContinuousOn v (Icc 0 1)) :
    Tendsto (fun n => ∫ x, v x ∂(sequenceLaw n).measure) atTop (𝓝 (v (1/2))) := by
  have hc : ContinuousAt v (1/2) := hv.continuousAt (Icc_mem_nhds (by norm_num) (by norm_num))
  have hl : Tendsto (fun n => 1/2-radius n) atTop (𝓝 (1/2:ℝ)) := by
    simpa using tendsto_const_nhds.sub radius_tendsto
  have hr : Tendsto (fun n => 1/2+radius n) atTop (𝓝 (1/2:ℝ)) := by
    simpa using tendsto_const_nhds.add radius_tendsto
  have ht := ((hc.tendsto.comp hl).add (hc.tendsto.comp hr)).div_const 2
  simpa [sequenceLaw, spreadLaw, integral_spread, left, right] using ht

lemma eventually_strict_below (z : Law) (hz : StrictBlackwell baseLaw z) :
    ∀ᶠ n in atTop, StrictBlackwell (sequenceLaw n) z := by
  obtain ⟨δ, hδ, hdom⟩ := eventually_small_spread_le z hz.2
  have hsmall : ∀ᶠ n in atTop, radius n < δ := (tendsto_order.1 radius_tendsto).2 δ hδ
  have hnot := hz.2
  unfold Blackwell at hnot
  push Not at hnot
  obtain ⟨v, hv, hc, hgap⟩ := hnot
  have hb : (∫ x, v x ∂baseLaw.measure) = v (1/2) := by
    rw [baseLaw, integral_uninformative]; rfl
  rw [hb] at hgap
  have hstrict : ∀ᶠ n in atTop, (∫ x, v x ∂(sequenceLaw n).measure) < ∫ x, v x ∂z.measure :=
    (tendsto_order.1 (integral_sequence_tendsto hv)).2 _ hgap
  filter_upwards [hsmall, hstrict] with n hn hne
  exact ⟨hdom _ (radius_mem n) hn.le, fun h => (hne.not_ge (h v hv hc))⟩

/-- Exactly the ambient topology generated by rays of the strict part of Blackwell order. -/
@[reducible] def strictRayTopology : TopologicalSpace Law :=
  TopologicalSpace.generateFrom
    (range (fun z : Law => {w | StrictBlackwell w z}) ∪
      range (fun z : Law => {w | StrictBlackwell z w}))

lemma ambient_convergence :
    Tendsto sequenceLaw atTop (@nhds Law strictRayTopology baseLaw) := by
  apply TopologicalSpace.tendsto_nhds_generateFrom_iff.2
  intro s hs hbase
  rcases hs with ⟨z, rfl⟩ | ⟨z, rfl⟩
  · exact eventually_strict_below z hbase
  · exact False.elim (hbase.2 (base_le z))

def chainCarrier : Set Law := insert baseLaw (range sequenceLaw)

lemma sequence_in_chain (n : ℕ) : sequenceLaw n ∈ chainCarrier :=
  mem_insert_of_mem _ (mem_range_self n)
lemma base_in_chain : baseLaw ∈ chainCarrier := mem_insert _ _

lemma sequence_antitone {m n : ℕ} (hmn : m ≤ n) :
    Blackwell (sequenceLaw n) (sequenceLaw m) :=
  spread_mono (radius_mem n) (radius_mem m) (radius_antitone hmn)

lemma chain_total : ∀ z ∈ chainCarrier, ∀ w ∈ chainCarrier,
    Blackwell z w ∨ Blackwell w z := by
  intro z hz w hw
  rcases hz with rfl | ⟨m, rfl⟩
  · exact Or.inl (base_le w)
  rcases hw with rfl | ⟨n, rfl⟩
  · exact Or.inr (base_le _)
  rcases le_total m n with h | h
  · exact Or.inr (sequence_antitone h)
  · exact Or.inl (sequence_antitone h)

lemma blackwell_chain : IsChain Blackwell chainCarrier := by
  intro z hz w hw hne
  exact chain_total z hz w hw

/-- The relative topology on the displayed chain, inherited from the full law space. -/
@[reducible] def chainTopology : TopologicalSpace chainCarrier :=
  TopologicalSpace.induced Subtype.val strictRayTopology

def chainSequence (n : ℕ) : chainCarrier := ⟨sequenceLaw n, sequence_in_chain n⟩
def chainLimit : chainCarrier := ⟨baseLaw, base_in_chain⟩

lemma relative_convergence :
    Tendsto chainSequence atTop (@nhds chainCarrier chainTopology chainLimit) := by
  letI : TopologicalSpace Law := strictRayTopology
  change Tendsto chainSequence atTop (@nhds chainCarrier
    (TopologicalSpace.induced Subtype.val strictRayTopology) chainLimit)
  rw [nhds_induced]
  change Tendsto chainSequence atTop (Filter.comap Subtype.val
    (@nhds Law strictRayTopology baseLaw))
  exact tendsto_comap_iff.2 ambient_convergence

lemma radius_lt_half (n : ℕ) : radius n < 1/2 := by
  unfold radius
  rw [div_lt_iff₀ (by positivity : (0:ℝ)<(n:ℝ)+1)]
  have hn : (0:ℝ) ≤ n := Nat.cast_nonneg n
  nlinarith

lemma dc_discrepancy_sequence (n : ℕ) :
    dcDiscrepancy (sequenceLaw n).measure baseLaw.measure = 2 :=
  dcDiscrepancy_spread_eq_two _ (radius_mem n) (radius_pos n)

lemma dc_discrepancy_not_tendsto_zero :
    ¬ Tendsto (fun n => dcDiscrepancy (sequenceLaw n).measure baseLaw.measure)
      atTop (𝓝 (0:ℝ)) := by
  intro h
  have hc : Tendsto (fun n => dcDiscrepancy (sequenceLaw n).measure baseLaw.measure)
      atTop (𝓝 (2:ℝ)) := by
    simpa only [dc_discrepancy_sequence] using
      (tendsto_const_nhds : Tendsto (fun _ : ℕ => (2:ℝ)) atTop (𝓝 (2:ℝ)))
  have he : (2:ℝ)=0 := tendsto_nhds_unique hc h
  norm_num at he

/-- Every integral in the supremum is an ordinary, integrable real integral. -/
lemma all_test_integrals_defined (n : ℕ) (v : Posterior → ℝ) :
    Integrable v (sequenceLaw n).measure ∧ Integrable v baseLaw.measure := by
  refine ⟨integrable_spread _ _ v, ?_⟩
  change Integrable v (Measure.dirac center)
  exact integrable_dirac (by simp)

/-- The full counterexample to the published uniform-DC convergence claim:
actual fixed-mean probability laws, ambient strict-ray convergence, its induced
chain convergence, admissible continuous convex-difference tests, integrability,
and an exact discrepancy of two at every term. No convergence or Jensen
hypothesis is left as an assumption. -/
theorem complete_information_counterexample :
    IsCompact (univ : Set Posterior) ∧
    IsProbabilityMeasure baseLaw.measure ∧
    (∫ x, (x:ℝ) ∂baseLaw.measure)=1/2 ∧
    Antitone radius ∧ Tendsto radius atTop (𝓝 (0:ℝ)) ∧
    IsChain Blackwell chainCarrier ∧
    Tendsto sequenceLaw atTop (@nhds Law strictRayTopology baseLaw) ∧
    Tendsto chainSequence atTop (@nhds chainCarrier chainTopology chainLimit) ∧
    (∀ n : ℕ, 0 < radius n ∧ radius n < 1/2 ∧
      IsProbabilityMeasure (sequenceLaw n).measure ∧
      (∫ x, (x:ℝ) ∂(sequenceLaw n).measure)=1/2 ∧
      NormalizedDCTest (test (radius n)) ∧
      (∀ v : Posterior → ℝ, Integrable v (sequenceLaw n).measure ∧
        Integrable v baseLaw.measure) ∧
      dcDiscrepancy (sequenceLaw n).measure baseLaw.measure=2) ∧
    ¬ Tendsto (fun n => dcDiscrepancy (sequenceLaw n).measure baseLaw.measure)
      atTop (𝓝 (0:ℝ)) := by
  refine ⟨isCompact_univ, inferInstance, baseLaw.mean, radius_antitone, radius_tendsto, blackwell_chain,
    ambient_convergence, relative_convergence, ?_, dc_discrepancy_not_tendsto_zero⟩
  intro n
  exact ⟨radius_pos n, radius_lt_half n, inferInstance, (sequenceLaw n).mean,
    test_normalizedDC _ (radius_pos n), all_test_integrals_defined n,
    dc_discrepancy_sequence n⟩

end Envelope.InformationCounterexample
