import Envelope.UniformQuotients
import Envelope.EnvelopeConsequences

/-!
# A measurable point-spike counterexample

The action set is the two-point type `Bool`, the payoff is constant in type,
and the selected rule chooses action one only at type one half.  All shifted
integrals exist and vanish.  The selected deviation quotients are genuinely
measurable and uniformly integrable, but the actual value function is not
continuous or absolutely continuous.  This separates an a.e. integral
condition from regularity of a specified pointwise representative.
-/

open Set MeasureTheory Filter
open scoped Topology ENNReal NNReal

namespace Envelope.SpikeCounterexample

noncomputable def center : ℝ := 1 / 2

def payoff (x : Bool) (_t : ℝ) : ℝ := if x then 1 else 0

noncomputable def rule (t : ℝ) : Bool := decide (t = center)

noncomputable def value (t : ℝ) : ℝ := if t = center then 1 else 0

theorem selected_value (t : ℝ) : payoff (rule t) t = value t := by
  simp [payoff, rule, value]

theorem selected_payoff (u t : ℝ) : payoff (rule u) t = value u := by
  simp [payoff, rule, value]

theorem hasDerivAt_payoff (x : Bool) (t : ℝ) : HasDerivAt (payoff x) 0 t := by
  exact hasDerivAt_const t _

theorem measurable_value : Measurable value := by
  exact measurable_const.ite (measurableSet_singleton center) measurable_const

theorem value_ae_zero (μ : Measure ℝ) [NoAtoms μ] : value =ᵐ[μ] 0 := by
  filter_upwards [μ.ae_ne center] with s hs
  simp [value, hs]

noncomputable def shiftedPayoff (h s : ℝ) : ℝ := payoff (rule (s + h)) s

theorem shiftedPayoff_eq (h s : ℝ) : shiftedPayoff h s = value (s + h) :=
  selected_payoff _ _

theorem measurable_shiftedPayoff (h : ℝ) : Measurable (shiftedPayoff h) := by
  rw [show shiftedPayoff h = (fun s => value (s + h)) from funext (shiftedPayoff_eq h)]
  exact measurable_value.comp (measurable_id.add_const h)

theorem shiftedPayoff_ae_zero (h : ℝ) (μ : Measure ℝ) [NoAtoms μ] :
    shiftedPayoff h =ᵐ[μ] 0 := by
  filter_upwards [μ.ae_ne (center - h)] with s hs
  have hne : s + h ≠ center := by intro he; apply hs; linarith
  simp [shiftedPayoff_eq, value, hne]

theorem integrable_shiftedPayoff (h : ℝ) (μ : Measure ℝ) [NoAtoms μ] :
    Integrable (shiftedPayoff h) μ := by
  exact (integrable_zero ℝ ℝ μ).congr (shiftedPayoff_ae_zero h μ).symm

theorem intervalIntegrable_shiftedPayoff (h a b : ℝ) :
    IntervalIntegrable (shiftedPayoff h) volume a b := by
  exact (integrable_shiftedPayoff h volume).intervalIntegrable

theorem integral_shiftedPayoff (h a b : ℝ) :
    (∫ s in a..b, shiftedPayoff h s) = 0 := by
  apply intervalIntegral.integral_zero_ae
  filter_upwards [shiftedPayoff_ae_zero h volume] with s hs
  exact fun _ => hs

noncomputable def shiftIntegral (a b h : ℝ) : ℝ :=
  ∫ s in a..b, shiftedPayoff h s

theorem outer_first_order_condition (a b : ℝ) :
    HasDerivAt (shiftIntegral a b) 0 0 := by
  have he : shiftIntegral a b = fun _ => 0 := by
    funext h
    exact integral_shiftedPayoff h a b
  rw [he]
  exact hasDerivAt_const _ _

noncomputable def selectedQuotient (h s : ℝ) : ℝ :=
  (shiftedPayoff h s - payoff (rule s) s) / h

theorem selectedQuotient_eq (h s : ℝ) :
    selectedQuotient h s = (value (s + h) - value s) / h := by
  simp [selectedQuotient, shiftedPayoff_eq, selected_value]

theorem measurable_selectedQuotient (h : ℝ) : Measurable (selectedQuotient h) := by
  rw [show selectedQuotient h = (fun s => (value (s + h) - value s) / h)
    from funext (selectedQuotient_eq h)]
  exact ((measurable_value.comp (measurable_id.add_const h)).sub measurable_value).div_const h

theorem support_selectedQuotient (h : ℝ) :
    Function.support (selectedQuotient h) ⊆ {center - h, center} := by
  intro s hs
  by_contra hn
  have hn' : s ≠ center - h ∧ s ≠ center := by simpa using hn
  have hne : s + h ≠ center := by intro he; apply hn'.1; linarith
  apply hs
  simp [selectedQuotient_eq, value, hne, hn'.2]

theorem selectedQuotient_ae_zero (h : ℝ) (μ : Measure ℝ) [NoAtoms μ] :
    selectedQuotient h =ᵐ[μ] 0 := by
  filter_upwards [shiftedPayoff_ae_zero h μ, value_ae_zero μ] with s hs hv
  simp [selectedQuotient, hs, selected_value, hv]

theorem integrable_selectedQuotient (h : ℝ) (μ : Measure ℝ) [NoAtoms μ] :
    Integrable (selectedQuotient h) μ := by
  exact (integrable_zero ℝ ℝ μ).congr (selectedQuotient_ae_zero h μ).symm

theorem selectedQuotient_uniformIntegrable (μ : Measure ℝ) [NoAtoms μ] :
    UniformIntegrable selectedQuotient 1 μ := by
  have hz : UniformIntegrable (fun _ : ℝ => (0 : ℝ → ℝ)) 1 μ :=
    uniformIntegrable_const (by norm_num) (by norm_num) MemLp.zero
  exact hz.ae_eq (fun h => (selectedQuotient_ae_zero h μ).symm)

theorem imitation_eventually_zero (t : ℝ) (ht : t ≠ center) :
    (fun h => payoff (rule (t + h)) t) =ᶠ[𝓝 0] (fun _ => (0 : ℝ)) := by
  have hc : Tendsto (fun h : ℝ => t + h) (𝓝 0) (𝓝 t) := by
    simpa using tendsto_const_nhds.add (tendsto_id : Tendsto (fun h : ℝ => h) (𝓝 0) (𝓝 0))
  filter_upwards [hc.eventually (eventually_ne_nhds ht)] with h hh
  simp [selected_payoff, value, hh]

theorem imitation_hasDerivAt (t : ℝ) (ht : t ≠ center) :
    HasDerivAt (fun h => payoff (rule (t + h)) t) 0 0 := by
  exact (hasDerivAt_const 0 (0 : ℝ)).congr_of_eventuallyEq (imitation_eventually_zero t ht)

theorem imitation_hasDerivAt_ae :
    ∀ᵐ t ∂volume, HasDerivAt (fun h => payoff (rule (t + h)) t) 0 0 := by
  filter_upwards [volume.ae_ne center] with t ht
  exact imitation_hasDerivAt t ht

theorem selectedQuotient_tendsto (t : ℝ) (ht : t ≠ center) :
    Tendsto (fun h => selectedQuotient h t) (𝓝 0) (𝓝 0) := by
  apply tendsto_const_nhds.congr'
  filter_upwards [imitation_eventually_zero t ht] with h hh
  simp [selectedQuotient, shiftedPayoff, hh, selected_value, value, ht]

theorem selectedQuotient_tendsto_ae :
    ∀ᵐ t ∂volume, Tendsto (fun h => selectedQuotient h t) (𝓝 0) (𝓝 0) := by
  filter_upwards [volume.ae_ne center] with t ht
  exact selectedQuotient_tendsto t ht

/-- The paper's selected quotient on its actual domain, extended by zero
unless both the original and the shifted type belong to the unit interval. -/
noncomputable def admissibleSelectedQuotient (h s : ℝ) : ℝ :=
  (Envelope.QuadraticNull.admissibleShift h).indicator (selectedQuotient h) s

theorem measurable_admissibleSelectedQuotient (h : ℝ) :
    Measurable (admissibleSelectedQuotient h) := by
  exact (measurable_selectedQuotient h).indicator
    (Envelope.QuadraticNull.measurableSet_admissibleShift h)

theorem admissibleSelectedQuotient_ae_zero (h : ℝ) (μ : Measure ℝ) [NoAtoms μ] :
    admissibleSelectedQuotient h =ᵐ[μ] 0 := by
  filter_upwards [selectedQuotient_ae_zero h μ] with s hs
  simp [admissibleSelectedQuotient, hs]

theorem integrable_admissibleSelectedQuotient (h : ℝ) (μ : Measure ℝ) [NoAtoms μ] :
    Integrable (admissibleSelectedQuotient h) μ := by
  exact (integrable_zero ℝ ℝ μ).congr (admissibleSelectedQuotient_ae_zero h μ).symm

theorem admissibleSelectedQuotient_uniformIntegrable (μ : Measure ℝ) [NoAtoms μ] :
    UniformIntegrable admissibleSelectedQuotient 1 μ := by
  have hz : UniformIntegrable (fun _ : ℝ => (0 : ℝ → ℝ)) 1 μ :=
    uniformIntegrable_const (by norm_num) (by norm_num) MemLp.zero
  exact hz.ae_eq (fun h => (admissibleSelectedQuotient_ae_zero h μ).symm)

theorem admissibleSelectedQuotient_tendsto (t : ℝ) (ht : t ≠ center) :
    Tendsto (fun h => admissibleSelectedQuotient h t) (𝓝 0) (𝓝 0) := by
  apply tendsto_const_nhds.congr'
  filter_upwards [imitation_eventually_zero t ht] with h hh
  have hq : selectedQuotient h t = 0 := by
    simp [selectedQuotient, shiftedPayoff, hh, selected_value, value, ht]
  by_cases hdom : t ∈ Envelope.QuadraticNull.admissibleShift h
  · rw [admissibleSelectedQuotient, indicator_of_mem hdom, hq]
  · rw [admissibleSelectedQuotient, indicator_of_notMem hdom]

theorem admissibleSelectedQuotient_tendsto_ae :
    ∀ᵐ t ∂volume, Tendsto (fun h => admissibleSelectedQuotient h t) (𝓝 0) (𝓝 0) := by
  filter_upwards [volume.ae_ne center] with t ht
  exact admissibleSelectedQuotient_tendsto t ht

/-- This is the actual supremum over the two feasible actions, with the
usual zero extension outside the admissible type-shift domain. -/
noncomputable def actualQuotientSup (h s : ℝ) : ℝ :=
  (Envelope.QuadraticNull.admissibleShift h).indicator
    (fun s => sSup (Set.range (fun x : Bool =>
      |(payoff x (s + h) - payoff x s) / h|))) s

theorem actualQuotientSup_zero (h : ℝ) : actualQuotientSup h = 0 := by
  funext s
  simp [actualQuotientSup, payoff]

theorem actualQuotientSup_uniformIntegrable (μ : Measure ℝ) :
    UniformIntegrable actualQuotientSup 1 μ := by
  have he : actualQuotientSup = fun _ : ℝ => (0 : ℝ → ℝ) := by
    funext h
    exact actualQuotientSup_zero h
  rw [he]
  exact uniformIntegrable_const (by norm_num) (by norm_num) MemLp.zero

theorem measurable_actualQuotientSup (h : ℝ) : Measurable (actualQuotientSup h) := by
  rw [actualQuotientSup_zero]
  exact measurable_zero

theorem value_not_continuousOn : ¬ ContinuousOn value (Icc (0 : ℝ) 1) := by
  intro hc
  have hsub : Icc (0 : ℝ) center ⊆ Icc (0 : ℝ) 1 := by
    intro s hs
    constructor
    · exact hs.1
    · linarith [hs.2, show center = (1 / 2 : ℝ) from rfl]
  have he : EqOn value (fun _ : ℝ => 0) (Ioo (0 : ℝ) center) := by
    intro t ht
    simp [value, ne_of_lt ht.2]
  have he' : EqOn value (fun _ : ℝ => 0) (Icc (0 : ℝ) center) :=
    he.of_subset_closure (hc.mono hsub) continuousOn_const Ioo_subset_Icc_self
      (by rw [closure_Ioo (by norm_num [center] : (0 : ℝ) ≠ center)])
  have := he' (show center ∈ Icc (0 : ℝ) center by norm_num [center])
  simp [value] at this

theorem value_not_absolutelyContinuous : ¬ AbsolutelyContinuousOnInterval value 0 1 := by
  intro hc
  apply value_not_continuousOn
  simpa only [uIcc_of_le (by norm_num : (0 : ℝ) ≤ 1)] using hc.continuousOn

theorem envelope_fails :
    payoff (rule center) center ≠ payoff (rule 0) 0 +
      ∫ s in (0 : ℝ)..center, deriv (payoff (rule s)) s := by
  have hd : (fun s : ℝ => deriv (payoff (rule s)) s) = fun _ => 0 := by
    funext s
    exact (hasDerivAt_payoff (rule s) s).deriv
  rw [hd]
  norm_num [selected_value, value, center]

/-- All parts concern the same explicit two-action payoff and the same rule.
The integral statements include integrability, so the certificate does not
exploit the totalized value of Lean's integral on inadmissible functions.
The actual fixed-action supremum verifies the paper's basic hypothesis;
UI and a.e. convergence of the selected quotients verify the disputed
weakened hypotheses, whereas the actual pointwise envelope is false. -/
theorem complete_counterexample :
    (∀ x t, HasDerivAt (payoff x) 0 t) ∧
    (∀ h, actualQuotientSup h = 0) ∧
    (∀ h, Measurable (actualQuotientSup h)) ∧
    UniformIntegrable actualQuotientSup 1 (volume.restrict (Icc (0 : ℝ) 1)) ∧
    (∀ h, Function.support (selectedQuotient h) ⊆ {center - h, center}) ∧
    (∀ h, Measurable (selectedQuotient h)) ∧
    (∀ h, Integrable (selectedQuotient h) (volume.restrict (Icc (0 : ℝ) 1))) ∧
    UniformIntegrable selectedQuotient 1 (volume.restrict (Icc (0 : ℝ) 1)) ∧
    (∀ h, Measurable (admissibleSelectedQuotient h)) ∧
    (∀ h, admissibleSelectedQuotient h =ᵐ[volume.restrict (Icc (0 : ℝ) 1)] 0) ∧
    (∀ h, Integrable (admissibleSelectedQuotient h)
      (volume.restrict (Icc (0 : ℝ) 1))) ∧
    UniformIntegrable admissibleSelectedQuotient 1 (volume.restrict (Icc (0 : ℝ) 1)) ∧
    (∀ᵐ t ∂(volume.restrict (Icc (0 : ℝ) 1)),
      Tendsto (fun h => admissibleSelectedQuotient h t) (𝓝 0) (𝓝 0)) ∧
    (∀ᵐ t ∂(volume.restrict (Icc (0 : ℝ) 1)),
      Tendsto (fun h => selectedQuotient h t) (𝓝 0) (𝓝 0)) ∧
    (∀ᵐ t ∂(volume.restrict (Icc (0 : ℝ) 1)),
      HasDerivAt (fun h => payoff (rule (t + h)) t) 0 0) ∧
    (∀ h a b, IntervalIntegrable (shiftedPayoff h) volume a b) ∧
    (∀ h a b, (∫ s in a..b, shiftedPayoff h s) = 0) ∧
    (∀ a b, HasDerivAt (shiftIntegral a b) 0 0) ∧
    (¬ ContinuousOn (fun t => payoff (rule t) t) (Icc (0 : ℝ) 1)) ∧
    (¬ AbsolutelyContinuousOnInterval (fun t => payoff (rule t) t) 0 1) ∧
    (payoff (rule center) center ≠ payoff (rule 0) 0 +
      ∫ s in (0 : ℝ)..center, deriv (payoff (rule s)) s) := by
  refine ⟨hasDerivAt_payoff, actualQuotientSup_zero, measurable_actualQuotientSup,
    actualQuotientSup_uniformIntegrable _, support_selectedQuotient,
    measurable_selectedQuotient, fun h => integrable_selectedQuotient h _,
    selectedQuotient_uniformIntegrable _,
    measurable_admissibleSelectedQuotient, fun h => admissibleSelectedQuotient_ae_zero h _,
    fun h => integrable_admissibleSelectedQuotient h _,
    admissibleSelectedQuotient_uniformIntegrable _,
    ae_restrict_of_ae admissibleSelectedQuotient_tendsto_ae,
    ae_restrict_of_ae selectedQuotient_tendsto_ae,
    ae_restrict_of_ae imitation_hasDerivAt_ae,
    intervalIntegrable_shiftedPayoff, integral_shiftedPayoff,
    outer_first_order_condition, ?_, ?_, envelope_fails⟩
  · simpa only [selected_value] using value_not_continuousOn
  · simpa only [selected_value] using value_not_absolutelyContinuous

end Envelope.SpikeCounterexample
